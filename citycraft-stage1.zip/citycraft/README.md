# CityCraft: Build Your City, Build Your Digital Government

Stage 1 of 10. A browser-based low-poly city game where the mayor shapes the physical city and, in later stages, the digital systems that govern it.

## Run it

You need Node.js 18 or newer.

```bash
npm install
npm run dev        # opens http://localhost:5173
```

Build a static site you can host anywhere (any folder or sub-path):

```bash
npm run build      # output in dist/
npm run preview    # check the built site locally
```

Run the logic tests (no browser needed):

```bash
npm test
```

**Without npm:** serve the project folder with any static server (for example `python3 -m http.server 8000`) and open `http://localhost:8000`. In this mode three.js is loaded from a CDN through the import map in `index.html`, so you need an internet connection. Opening `index.html` directly from disk will not work because browsers block ES modules on `file://`.

## Controls

| Action | Input |
|---|---|
| Select a plot | Click |
| Pan | Drag, or W A S D / arrow keys |
| Rotate and tilt | Right-drag or Shift+drag, Q and E |
| Zoom | Scroll, pinch, or + and - |
| Reset camera | Home |
| Pause or resume | Space |
| Speed 1×, 2×, 4× | 1, 2, 3 |
| Tools: inspect, clear trees, plant a tree | V, C, T |
| Save | Ctrl+S or Cmd+S |
| Back or close | Esc |

## What is in stage 1

- 32 × 32 low-poly island with grass and meadow plots, a lake with a shore, forests and drifting clouds. The map is generated from a seed, so the same seed always gives the same city.
- Four wards (Hillcrest, Lakeside, Old Market, Greenfield) with coloured boundaries, floating labels and a tint overlay. Each ward is a record in the boundary registry.
- Orbit, pan and zoom with smoothing; hover highlight; raycast tile selection; mini-map that shows the camera and moves it on click.
- Inspector for plots (what is on the ground, which records exist) and wards (land use, boundary record).
- Landscaping: clear trees (50 cr) and plant trees (20 cr). Every spend appears in the ledger.
- Simulation clock with pause, 1×, 2×, 4×. Monthly accounts close automatically.
- Save, load, autosave (configurable), save on page close, export and import a save file, start a new city, versioned migrations.
- Five starter missions that teach the controls through play.
- Views: City, Services (catalogue of shared platform services and the municipal applications built from them, read-only), Registries (boundary records, empty registries ready for later stages), Configure (city and ward names, autosave, saves), Insights (numbers, ward land use, missions, ledger, journal, engine check).

## Limitations

- Construction categories (roads, zoning, utilities, public services) are shown as locked. They are not active controls.
- Population and happiness are fixed at 0 and neutral until residents exist in a later stage.
- Platform services and municipal applications are defined as data and contracts only. Nothing runs yet.
- Saves live in this browser's localStorage. Clearing site data deletes them. Use Export to keep a copy.
- Mobile layout works for viewing but the game is designed for a laptop with a mouse.

See `docs/ARCHITECTURE.md` for how the code is organised and how to extend it.
