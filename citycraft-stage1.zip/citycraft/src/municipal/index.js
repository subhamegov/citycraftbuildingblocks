// Municipal applications: property tax, permits, licences, connections,
// grievances. Each one is a configuration of shared platform services that
// works on shared registry records.
//
// Stage 1 defines the state shape and the application contract only.

export function createMunicipalState(config) {
  const applications = {};
  for (const app of config.municipalApps.applications) {
    applications[app.id] = { enabled: false, enabledDay: null, settings: {} };
  }
  // Cases are individual transactions (an application, a bill, a complaint).
  // They reference registry ids and never copy registry data.
  return { applications, cases: {}, caseOrder: [], nextCaseSeq: 1 };
}

/**
 * Contract each municipal application will implement in later stages.
 * @typedef {object} MunicipalApplication
 * @property {string} id
 * @property {string[]} uses            Platform service ids it depends on.
 * @property {(state: object, ctx: object) => void} [onTick]
 * @property {object[]} commands        Command definitions registered with the store.
 */
export const municipalAppRegistry = new Map();

export function registerMunicipalApp(app) {
  if (!app?.id) throw new Error('Municipal application needs an id');
  municipalAppRegistry.set(app.id, app);
}

export function missingDependencies(config, state, appId) {
  const app = config.municipalApps.applications.find((a) => a.id === appId);
  if (!app) return [];
  return app.uses.filter((svc) => state.platform.services[svc]?.status !== 'active');
}
