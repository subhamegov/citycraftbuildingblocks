import { runSystems } from './systems.js';

export const simulationCommands = [
  {
    type: 'sim/setSpeed',
    touches: ['simulation'],
    validate(_state, { speed }, ctx) {
      return ctx.config.game.simulation.speeds.includes(speed) ? null : `Speed ${speed} is not allowed`;
    },
    apply(state, { speed }) {
      state.simulation.speed = speed;
    },
  },
  {
    // One simulated day. Deterministic: depends only on state and config.
    type: 'sim/tick',
    touches: ['simulation'],
    apply(state, _payload, ctx) {
      state.simulation.day += 1;
      ctx.day = state.simulation.day;
      runSystems(state, ctx);
      ctx.emit('sim.day', { day: state.simulation.day });
    },
  },
];
