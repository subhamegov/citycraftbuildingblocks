// Game calendar. Day 0 is 1 January of Year 1. Uses a real calendar under the
// hood (anchored to a fixed epoch) so months have their usual lengths.

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const DAY_MS = 86400000;
const EPOCH = Date.UTC(2001, 0, 1);
const EPOCH_YEAR = 2001;

export function dateParts(day) {
  const d = new Date(EPOCH + day * DAY_MS);
  return { year: d.getUTCFullYear() - EPOCH_YEAR + 1, month: d.getUTCMonth(), date: d.getUTCDate() };
}

export function formatGameDate(day) {
  const { year, month, date } = dateParts(day);
  return `${date} ${MONTHS[month]}, Year ${year}`;
}

export function monthKey(day) {
  const { year, month } = dateParts(day);
  return `Y${year}-${String(month + 1).padStart(2, '0')}`;
}

export function monthLabel(day) {
  const { year, month } = dateParts(day);
  return `${MONTHS[month]} Year ${year}`;
}

export function isFirstOfMonth(day) {
  return dateParts(day).date === 1;
}
