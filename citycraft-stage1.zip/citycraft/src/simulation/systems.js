// Ordered list of daily simulation systems. Later stages register their own
// systems (population, utilities, services) here. Order is fixed so a day
// always plays out the same way.

import { monthlyAccountsSystem } from './economy.js';

const systems = [];

export function registerSystem(system, { before } = {}) {
  if (!system?.id || typeof system.run !== 'function') throw new Error('A system needs an id and run()');
  if (systems.some((s) => s.id === system.id)) return;
  const index = before ? systems.findIndex((s) => s.id === before) : -1;
  if (index >= 0) systems.splice(index, 0, system);
  else systems.push(system);
}

export function listSystems() {
  return systems.map((s) => s.id);
}

export function runSystems(state, ctx) {
  for (const system of systems) system.run(state, ctx);
}

// Stage 1 systems
registerSystem(monthlyAccountsSystem);
