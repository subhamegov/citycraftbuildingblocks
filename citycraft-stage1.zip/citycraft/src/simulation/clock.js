// Turns real time into simulated days. The clock only decides *when* to
// dispatch sim/tick; what happens in a day is decided by the command.

export class SimulationClock {
  constructor(store) {
    this.store = store;
    this.accumulator = 0;
  }

  get settings() {
    return this.store.config.game.simulation;
  }

  /** @param {number} dtMs real milliseconds since last frame */
  update(dtMs) {
    const speed = this.store.getState().simulation.speed;
    if (!speed) {
      this.accumulator = 0;
      return 0;
    }
    // Clamp long pauses (hidden tab) so the city does not jump weeks ahead.
    this.accumulator += Math.min(dtMs, 250) * speed;
    let steps = 0;
    const max = this.settings.maxStepsPerFrame;
    while (this.accumulator >= this.settings.msPerDay && steps < max) {
      this.accumulator -= this.settings.msPerDay;
      this.store.dispatch('sim/tick');
      steps += 1;
    }
    if (steps === max) this.accumulator = 0;
    return steps;
  }

  reset() {
    this.accumulator = 0;
  }
}
