// City finances. Every change to the treasury goes through postTransaction so
// there is always a ledger entry explaining it.

import { isFirstOfMonth, monthKey, monthLabel } from './calendar.js';

export function createEconomyState(config) {
  return {
    treasury: config.game.startingTreasury,
    ledger: [],
    nextTxnSeq: 1,
    months: [],
  };
}

export function canAfford(state, amount) {
  return state.economy.treasury >= amount;
}

/** amount is positive for income, negative for spending. Call only inside commands. */
export function postTransaction(state, { amount, category, memo, ref = null }, ctx) {
  const economy = state.economy;
  economy.treasury += amount;
  const entry = {
    id: `TX-${String(economy.nextTxnSeq).padStart(6, '0')}`,
    day: state.simulation.day,
    amount,
    category,
    memo,
    ref,
    balance: economy.treasury,
  };
  economy.nextTxnSeq += 1;
  economy.ledger.push(entry);
  const limit = ctx?.config?.game?.ledgerLimit ?? 200;
  if (economy.ledger.length > limit) economy.ledger.splice(0, economy.ledger.length - limit);
  ctx?.touch('economy');
  ctx?.emit('economy.transaction', { amount, category });
  return entry;
}

/** Simulation system: close the books at the start of each month. */
export const monthlyAccountsSystem = {
  id: 'economy.monthlyAccounts',
  run(state, ctx) {
    const day = state.simulation.day;
    if (day === 0 || !isFirstOfMonth(day)) return;
    const closingKey = monthKey(day - 1);
    const entries = state.economy.ledger.filter((e) => monthKey(e.day) === closingKey);
    const income = entries.filter((e) => e.amount > 0).reduce((s, e) => s + e.amount, 0);
    const spending = entries.filter((e) => e.amount < 0).reduce((s, e) => s - e.amount, 0);
    state.economy.months.push({
      key: closingKey,
      label: monthLabel(day - 1),
      income,
      spending,
      closingBalance: state.economy.treasury,
    });
    if (state.economy.months.length > 36) state.economy.months.shift();
    ctx.touch('economy');
    ctx.journal(`Accounts closed for ${monthLabel(day - 1)}.`);
  },
};
