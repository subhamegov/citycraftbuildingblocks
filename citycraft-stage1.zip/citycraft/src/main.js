// CityCraft entry point. Wires config, state, store, persistence, simulation,
// renderer and interface together. Each part only talks to the others through
// the store (state + commands) or through small event interfaces.

import { loadConfig } from './config/configService.js';
import { createStore, newGameState } from './app/createGame.js';
import { Persistence } from './state/persistence.js';
import { SimulationClock } from './simulation/clock.js';
import { randomSeed } from './core/rng.js';
import { createActions } from './app/actions.js';
import { connectRenderer } from './app/rendererBridge.js';
import { mountApp } from './ui/app.js';
import { installShortcuts } from './ui/shortcuts.js';
import { notify } from './ui/overlays.js';
import { $, h, replaceChildren } from './ui/dom.js';
import { icon } from './ui/icons.js';
import { fmt } from './ui/format.js';
import { getTile, plotStatus } from './physical/tiles.js';
import { wardName } from './registries/index.js';

async function boot() {
  const config = await loadConfig();

  // 1. State: newest valid save, or a new city.
  const persistence = new Persistence();
  let state = null;
  let firstRun = false;
  const slot = persistence.latestSlot();
  if (slot) {
    try {
      state = persistence.read(slot).state;
    } catch (err) {
      console.warn('[CityCraft] could not read save', err);
      queueMicrotask(() => notify(`Your saved city could not be loaded: ${err.message}`, 'error', { timeout: 8000 }));
    }
  }
  if (!state) {
    state = newGameState(config, { seed: randomSeed() });
    firstRun = true;
  }

  // 2. Store, persistence and simulation clock.
  const store = createStore(config, state);
  persistence.attach(store);
  const clock = new SimulationClock(store);

  // 3. Renderer (optional if WebGL is missing; the rest of the game still works).
  let renderer = null;
  let minimap = null;
  const viewport = $('#viewport');
  try {
    const [{ CityRenderer, webglAvailable }, { Minimap }] = await Promise.all([import('./render/cityRenderer.js'), import('./render/minimap.js')]);
    if (!webglAvailable()) throw new Error('WebGL is not available in this browser');
    renderer = new CityRenderer(viewport);
    minimap = new Minimap($('#minimap'));
  } catch (err) {
    console.error(err);
    replaceChildren(viewport, h('div', { class: 'viewport-error' }, icon('info', { size: 22 }), h('strong', {}, 'The 3D city could not start.'), h('span', {}, err.message)));
  }

  let ui = null;
  const actions = createActions({
    store,
    config,
    persistence,
    clock,
    hooks: { onSaved: (res) => ui?.setSaveStatus(`Saved ${fmt.date(res.envelope.day)}`) },
  });
  persistence.onAutosave = (res) => ui?.setSaveStatus(res.ok ? `Autosaved ${fmt.date(res.envelope.day)}` : 'Autosave failed');

  // 4. Interface
  ui = mountApp({
    store,
    config,
    persistence,
    actions,
    diagnostics: renderer ? () => renderer.stats() : null,
    onViewChange: (view) => renderer?.setActive(view === 'city'),
  });
  installShortcuts({ store, config, actions, renderer });

  // 5. Bridge renderer <-> store
  const hoverChip = $('#hover-info');
  if (renderer) {
    connectRenderer({
      store,
      config,
      renderer,
      minimap,
      actions,
      onHover: (pos) => {
        if (!pos) {
          hoverChip.hidden = true;
          return;
        }
        const s = store.getState();
        const tile = getTile(s.world, pos.x, pos.y);
        if (!tile) return;
        replaceChildren(
          hoverChip,
          h('strong', {}, wardName(s.registries, tile.ward)),
          h('span', {}, config.terrain.types[tile.terrain]?.label ?? tile.terrain),
          h('span', {}, plotStatus(config, tile).label),
          h('span', { class: 'mono' }, `${tile.x}, ${tile.y}`),
        );
        hoverChip.hidden = false;
      },
    });
    installCameraButtons(renderer);
  }

  // 6. Main loop
  let last = performance.now();
  let frame = 0;
  function loop(now) {
    const dt = now - last;
    last = now;
    clock.update(dt);
    if (renderer) {
      renderer.frame(dt);
      if (++frame % 6 === 0) minimap.setCamera(renderer.controller.current);
    }
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);

  // Save on the way out so a reload resumes exactly here.
  window.addEventListener('pagehide', () => {
    if (store.getState().ui.settings.autosave) persistence.save('auto');
  });

  $('#boot')?.remove();
  if (firstRun) actions.welcome();

  // Handy for debugging and for later stages' dev tools.
  window.citycraft = { store, config, persistence, renderer, actions, version: store.getState().meta.version };
}

function installCameraButtons(renderer) {
  const c = renderer.controller;
  const btn = (iconName, tip, fn) => h('button', { class: 'cam-btn', 'data-tip': tip, 'aria-label': tip, onClick: fn }, icon(iconName, { size: 16 }));
  replaceChildren(
    $('#camera-controls'),
    btn('rotateLeft', 'Rotate left (Q)', () => c.rotateBy(-Math.PI / 4)),
    btn('rotateRight', 'Rotate right (E)', () => c.rotateBy(Math.PI / 4)),
    btn('plus', 'Zoom in (+)', () => c.zoomBy(0.8)),
    btn('minus', 'Zoom out (-)', () => c.zoomBy(1.25)),
    btn('home', 'Reset view (Home)', () => renderer.setCamera(null, false)),
  );
}

boot().catch((err) => {
  console.error(err);
  const bootEl = document.getElementById('boot');
  if (bootEl) bootEl.textContent = `CityCraft could not start: ${err.message}`;
});
