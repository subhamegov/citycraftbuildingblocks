// Loads the JSON game configuration. Config is data, not code: balancing
// numbers, ward names, catalogues and missions live in ./data/*.json so later
// stages can extend the game without touching the engine.

import { deepFreeze } from '../core/readonly.js';

export const CONFIG_FILES = {
  game: new URL('./data/game.json', import.meta.url),
  wards: new URL('./data/wards.json', import.meta.url),
  terrain: new URL('./data/terrain.json', import.meta.url),
  construction: new URL('./data/construction.json', import.meta.url),
  registries: new URL('./data/registries.json', import.meta.url),
  platformServices: new URL('./data/platform-services.json', import.meta.url),
  municipalApps: new URL('./data/municipal-apps.json', import.meta.url),
  missions: new URL('./data/missions.json', import.meta.url),
};

async function fetchJson(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Could not load config ${url} (${res.status})`);
  return res.json();
}

/**
 * @param {(key: string, url: URL) => Promise<object>} loader  Injectable for tests.
 */
export async function loadConfig(loader = (_key, url) => fetchJson(url)) {
  const entries = await Promise.all(
    Object.entries(CONFIG_FILES).map(async ([key, url]) => [key, await loader(key, url)]),
  );
  const config = Object.fromEntries(entries);
  validateConfig(config);
  return deepFreeze(config);
}

export function validateConfig(config) {
  const problems = [];
  const { grid } = config.game || {};
  if (!grid || grid.width < 8 || grid.height < 8) problems.push('game.grid must be at least 8 x 8');
  if (!Array.isArray(config.wards?.wards) || config.wards.wards.length !== 4) problems.push('wards.json must define 4 wards');
  const codes = new Set((config.wards?.wards || []).map((w) => w.code));
  if (codes.size !== (config.wards?.wards || []).length) problems.push('ward codes must be unique');
  if (!config.terrain?.types?.grass) problems.push('terrain.types.grass is required');
  if (problems.length) throw new Error(`Invalid config: ${problems.join('; ')}`);
}

export function wardConfig(config, code) {
  return config.wards.wards.find((w) => w.code === code);
}

export function costOf(config, key) {
  return config.game.costs[key] ?? 0;
}
