// Assembles every command group into one registry. Later stages add their
// groups here (roads, zoning, services, ...).

import { createCommandRegistry } from '../core/store.js';
import { simulationCommands } from '../simulation/commands.js';
import { physicalCommands } from '../physical/commands.js';
import { registryCommands } from '../registries/commands.js';
import { uiCommands, metaCommands } from './uiCommands.js';
import { missionsReaction } from '../analytics/missions.js';

export function buildCommands() {
  return createCommandRegistry(simulationCommands, physicalCommands, registryCommands, uiCommands, metaCommands);
}

export const reactions = [missionsReaction];
