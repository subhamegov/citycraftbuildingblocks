// Connects the store to the renderer and minimap.
//   state changes  -> renderer.setWorld / updateWorld / setSelection ...
//   player intent  -> store.dispatch(command)
// Neither side knows about the other.

import { REPLACE } from '../core/store.js';
import { buildWorldView } from './worldView.js';
import { isBuildableTerrain } from '../physical/tiles.js';

export function connectRenderer({ store, config, renderer, minimap, actions, onHover }) {
  const view = () => buildWorldView(store.getState(), config);
  let lastSelectionKey = null;

  const toolValidator = (tool) => {
    if (tool === 'clearTree') return (tile) => Boolean(tile.tree);
    if (tool === 'plantTree') return (tile) => isBuildableTerrain(config, tile.terrain) && !tile.tree && !tile.structure;
    return null;
  };

  function syncUi(state, { focus = true } = {}) {
    renderer.setOverlays(state.ui.overlays);
    renderer.setSelection(state.ui.selection);
    renderer.setTool(state.ui.activeTool, toolValidator(state.ui.activeTool));
    minimap?.setSelection(state.ui.selection);
    const key = JSON.stringify(state.ui.selection);
    if (focus && key !== lastSelectionKey && state.ui.selection?.kind === 'ward') renderer.focusWard(state.ui.selection.code);
    lastSelectionKey = key;
  }

  function full(state) {
    const v = view();
    renderer.setWorld(v);
    minimap?.setWorld(v, { wardTint: state.ui.overlays.wards });
    lastSelectionKey = JSON.stringify(state.ui.selection);
    syncUi(state, { focus: false });
    renderer.setCamera(state.ui.camera, true);
    minimap?.setCamera(renderer.getCamera());
  }

  const unsubscribe = store.subscribe((record, state) => {
    if (!record.ok) return;
    if (record.type === REPLACE) return full(state);
    const touched = new Set(record.touched);
    if (touched.has('world')) {
      const v = view();
      renderer.updateWorld(v);
      minimap?.setWorld(v, { wardTint: state.ui.overlays.wards });
    }
    if (touched.has('registries')) renderer.updateLabels(view());
    if (touched.has('ui') && record.type !== 'ui/setCamera') {
      if (record.type === 'ui/setOverlay') minimap?.setWorld(view(), { wardTint: state.ui.overlays.wards });
      syncUi(state);
    }
  });

  renderer.on('tileClick', (pos) => {
    if (!pos) return;
    const state = store.getState();
    const tool = state.ui.activeTool;
    if (tool === 'clearTree') actions.run('world/clearTree', pos);
    else if (tool === 'plantTree') actions.run('world/plantTree', pos);
    actions.run('ui/select', { selection: { kind: 'tile', x: pos.x, y: pos.y } });
  });

  renderer.on('hover', (pos) => onHover?.(pos));

  renderer.on('cameraSettled', ({ camera, userInitiated }) => {
    store.dispatch('ui/setCamera', { camera, userInitiated });
  });

  minimap?.onNavigate(({ x, y }) => renderer.focusTile(x, y));

  full(store.getState());
  return { unsubscribe, resync: () => full(store.getState()) };
}
