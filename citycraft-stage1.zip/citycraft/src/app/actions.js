// Player actions that involve more than one command or a side effect
// (saving, loading, files, dialogs). Everything that changes game state still
// goes through store.dispatch.

import { h } from '../ui/dom.js';
import { notify, openModal, closeModal, confirmDialog } from '../ui/overlays.js';
import { Button, Field, TextInput, Toggle } from '../ui/components.js';
import { newGameState } from './createGame.js';
import { randomSeed } from '../core/rng.js';
import { fmt } from '../ui/format.js';

export function createActions({ store, config, persistence, clock, hooks = {} }) {
  let lastSpeed = 1;

  const actions = {
    run(type, payload = {}, { quiet = false } = {}) {
      const res = store.dispatch(type, payload);
      if (!res.ok && !quiet) notify(res.error, 'warning');
      return res;
    },

    setSpeed(speed) {
      if (speed > 0) lastSpeed = speed;
      return actions.run('sim/setSpeed', { speed });
    },

    togglePause() {
      const speed = store.getState().simulation.speed;
      return actions.setSpeed(speed === 0 ? lastSpeed : 0);
    },

    openView(view) {
      return actions.run('ui/setView', { view });
    },

    selectWard(code) {
      if (store.getState().ui.activeView !== 'city') actions.openView('city');
      return actions.run('ui/select', { selection: { kind: 'ward', code } });
    },

    save() {
      const res = persistence.save('manual');
      if (res.ok) {
        notify(`Saved ${res.envelope.cityName} on ${fmt.date(res.envelope.day)}.`, 'success');
        hooks.onSaved?.(res);
      } else notify(res.error, 'error');
      return res;
    },

    async load(slot = 'manual') {
      const info = persistence.info(slot);
      if (!info) return notify('There is no saved city to load.', 'warning');
      const ok = await confirmDialog({
        title: 'Load saved city?',
        message: `This replaces the city on screen with the ${slot === 'auto' ? 'autosave' : 'save'} from ${fmt.date(info.day)}. Anything since then will be lost.`,
        confirmLabel: 'Load',
        tone: 'primary',
      });
      if (!ok) return;
      try {
        persistence.load(slot);
        clock.reset();
        notify(`Loaded ${info.cityName}, ${fmt.date(info.day)}.`, 'success');
      } catch (err) {
        notify(err.message, 'error', { timeout: 6000 });
      }
    },

    exportSave() {
      const text = persistence.exportText();
      const state = store.getState();
      const name = `${state.meta.cityName.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}-day-${state.simulation.day}.citycraft.json`;
      const url = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
      const a = h('a', { href: url, download: name });
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      notify(`Exported ${name}.`, 'success');
    },

    importSave() {
      const input = h('input', { type: 'file', accept: '.json,application/json', hidden: true });
      input.addEventListener('change', async () => {
        const file = input.files?.[0];
        input.remove();
        if (!file) return;
        try {
          const text = await file.text();
          persistence.importText(text);
          clock.reset();
          notify(`Imported ${file.name}.`, 'success');
        } catch (err) {
          notify(err.message, 'error', { timeout: 6000 });
        }
      });
      document.body.appendChild(input);
      input.click();
    },

    newCity() {
      const current = store.getState();
      const nameInput = TextInput({ id: 'new-city-name', value: current.meta.cityName, maxLength: 32 });
      let keepMap = false;
      openModal({
        title: 'Start a new city?',
        body: [
          h('p', {}, 'Your current city and its saves in this browser will be cleared. Export a copy first if you want to keep it.'),
          Field({ label: 'City name', id: 'new-city-name', control: nameInput }),
          Toggle({ label: 'Keep the same map', checked: false, onChange: (v) => (keepMap = v) }),
        ],
        actions: [
          Button({ label: 'Cancel', onClick: closeModal }),
          Button({
            label: 'Start new city',
            variant: 'danger',
            onClick: () => {
              const name = nameInput.value.trim();
              const cityName = name.length >= 2 ? name.slice(0, 32) : config.game.defaultCityName;
              const seed = keepMap ? current.meta.seed : randomSeed();
              closeModal();
              persistence.clearAll();
              store.replaceState(newGameState(config, { seed, cityName }), 'new');
              clock.reset();
              notify(`Welcome to ${cityName}.`, 'success');
            },
          }),
        ],
      });
    },

    showHelp() {
      const rows = [
        ['Select a plot', 'Click'],
        ['Pan', 'Drag, or W A S D / arrow keys'],
        ['Rotate and tilt', 'Right-drag or Shift+drag, Q and E'],
        ['Zoom', 'Scroll, pinch, or + and -'],
        ['Reset camera', 'Home'],
        ['Pause or resume', 'Space'],
        ['Speed 1×, 2×, 4×', '1, 2, 3'],
        ['Tools: inspect, clear, plant', 'V, C, T'],
        ['Save', 'Ctrl+S or Cmd+S'],
        ['Back or close', 'Esc'],
      ];
      openModal({
        title: 'How to play',
        body: [
          h('p', {}, 'You are the mayor. You shape the land, and the city keeps records of everything you build. Start by exploring your four wards and running the clock.'),
          h('dl', { class: 'kv kv-wide' }, rows.map(([a, b]) => [h('dt', {}, a), h('dd', {}, h('kbd', {}, b))])),
        ],
        actions: [Button({ label: 'Got it', variant: 'primary', onClick: closeModal })],
      });
    },

    welcome() {
      const state = store.getState();
      const nameInput = TextInput({ id: 'welcome-city-name', value: state.meta.cityName, maxLength: 32 });
      const start = () => {
        const name = nameInput.value.trim();
        if (name && name !== state.meta.cityName) actions.run('city/rename', { name });
        closeModal();
      };
      nameInput.addEventListener('keydown', (e) => e.key === 'Enter' && start());
      openModal({
        title: 'Welcome, Mayor',
        size: 'sm',
        body: [
          h(
            'p',
            {},
            'Your city is empty land split into four wards. Every plot you develop will also become a record that tax, permits and other services can share.',
          ),
          h('p', { class: 'muted small' }, 'Your first goals are in the left panel. Nothing is lost when you reload: the game saves to this browser.'),
          Field({ label: 'Name your city', id: 'welcome-city-name', control: nameInput }),
        ],
        actions: [Button({ label: 'Take office', variant: 'primary', onClick: start })],
      });
    },
  };
  return actions;
}
