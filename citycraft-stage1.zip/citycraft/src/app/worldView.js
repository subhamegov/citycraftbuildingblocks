// Builds the plain "world view" the renderer and minimap draw from. This is
// the only place where game state is translated for rendering, which keeps the
// renderer independent of registries, services and commands.

import { wardName } from '../registries/index.js';
import { isOpenPlot } from '../physical/tiles.js';

export function buildWorldView(state, config) {
  const { split } = config.wards;
  const { width, height } = state.world;
  const centres = {
    nw: { x: split.x / 2 - 0.5, y: split.y / 2 - 0.5 },
    ne: { x: (split.x + width) / 2 - 0.5, y: split.y / 2 - 0.5 },
    sw: { x: split.x / 2 - 0.5, y: (split.y + height) / 2 - 0.5 },
    se: { x: (split.x + width) / 2 - 0.5, y: (split.y + height) / 2 - 0.5 },
  };
  return {
    width,
    height,
    tiles: state.world.tiles,
    terrainColors: Object.fromEntries(Object.entries(config.terrain.types).map(([k, v]) => [k, v.color])),
    wards: config.wards.wards.map((w) => ({
      code: w.code,
      color: w.color,
      name: wardName(state.registries, w.code),
      center: centres[w.quadrant],
    })),
    isOpenPlot: (t) => isOpenPlot(config, t),
  };
}
