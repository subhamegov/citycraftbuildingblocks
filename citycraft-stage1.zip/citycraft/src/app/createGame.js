// Composition helper shared by the browser app and the tests.

import { Store } from '../core/store.js';
import { buildCommands, reactions } from './commandRegistry.js';
import { createInitialState } from '../state/initialState.js';

export function createStore(config, state, { strict = true } = {}) {
  return new Store({ state, commands: buildCommands(), reactions, context: { config }, strict });
}

export function newGameState(config, options) {
  return createInitialState(config, options);
}
