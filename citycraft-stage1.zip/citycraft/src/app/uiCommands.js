// Commands for player-facing interface state that is worth saving: the open
// view, the active tool, the selection, overlays, camera and settings.

import { getTile } from '../physical/tiles.js';

export const VIEWS = ['city', 'services', 'registries', 'configure', 'insights'];
export const OVERLAYS = ['wards', 'plots'];

function validSelection(state, sel, ctx) {
  if (sel === null) return true;
  if (sel.kind === 'tile') return Boolean(getTile(state.world, sel.x, sel.y));
  if (sel.kind === 'ward') return ctx.config.wards.wards.some((w) => w.code === sel.code);
  return false;
}

export const uiCommands = [
  {
    type: 'ui/setView',
    touches: ['ui'],
    validate: (_s, { view }) => (VIEWS.includes(view) ? null : `Unknown view ${view}`),
    apply(state, { view }) {
      state.ui.activeView = view;
    },
  },
  {
    type: 'ui/setTool',
    touches: ['ui'],
    validate: (_s, { tool }, ctx) =>
      ctx.config.construction.tools.some((t) => t.id === tool) ? null : `Unknown tool ${tool}`,
    apply(state, { tool }) {
      state.ui.activeTool = tool;
    },
  },
  {
    type: 'ui/select',
    touches: ['ui'],
    validate: (state, { selection }, ctx) => (validSelection(state, selection ?? null, ctx) ? null : 'Nothing to select there'),
    apply(state, { selection }) {
      state.ui.selection = selection ? { ...selection } : null;
    },
  },
  {
    type: 'ui/setOverlay',
    touches: ['ui'],
    validate: (_s, { overlay }) => (OVERLAYS.includes(overlay) ? null : `Unknown overlay ${overlay}`),
    apply(state, { overlay, on }) {
      state.ui.overlays[overlay] = on === undefined ? !state.ui.overlays[overlay] : Boolean(on);
    },
  },
  {
    // Saved camera pose, so a reload puts the mayor back where they were.
    type: 'ui/setCamera',
    touches: ['ui'],
    validate(_s, { camera }) {
      const keys = ['tx', 'tz', 'azimuth', 'polar', 'distance'];
      return camera && keys.every((k) => Number.isFinite(camera[k])) ? null : 'Invalid camera';
    },
    apply(state, { camera }) {
      const round = (n) => Math.round(n * 1000) / 1000;
      state.ui.camera = {
        tx: round(camera.tx),
        tz: round(camera.tz),
        azimuth: round(camera.azimuth),
        polar: round(camera.polar),
        distance: round(camera.distance),
      };
    },
  },
  {
    type: 'settings/update',
    touches: ['ui'],
    validate(_s, patch, ctx) {
      if ('autosaveEveryDays' in patch && !ctx.config.game.autosave.options.includes(patch.autosaveEveryDays)) {
        return 'Unsupported autosave interval';
      }
      return null;
    },
    apply(state, patch) {
      const allowed = ['autosave', 'autosaveEveryDays', 'showHints'];
      for (const key of allowed) if (key in patch) state.ui.settings[key] = patch[key];
    },
  },
];

export const metaCommands = [
  {
    type: 'city/rename',
    touches: ['meta'],
    validate(_s, { name }) {
      const clean = String(name ?? '').trim();
      return clean.length >= 2 && clean.length <= 32 ? null : 'City names need 2 to 32 characters';
    },
    apply(state, { name }, ctx) {
      state.meta.cityName = String(name).trim();
      ctx.journal(`The city is now called ${state.meta.cityName}.`);
    },
  },
  {
    // Recorded by persistence just before a manual save is written.
    type: 'meta/recordSave',
    touches: ['meta'],
    apply(state, { slot = 'manual' }) {
      if (slot === 'manual') state.meta.manualSaves += 1;
      state.meta.lastSavedDay = state.simulation.day;
    },
  },
];
