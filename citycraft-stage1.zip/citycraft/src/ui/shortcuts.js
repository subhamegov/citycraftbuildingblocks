import { isModalOpen, modalDismissible, closeModal, closeDrawer } from './overlays.js';
import { DEFAULT_CAMERA } from '../render/cameraController.js';

export function installShortcuts({ store, config, actions, renderer }) {
  const toolKeys = Object.fromEntries(config.construction.tools.map((t) => [t.shortcut.toLowerCase(), t.id]));
  const speeds = config.game.simulation.speeds.filter((s) => s > 0);

  window.addEventListener('keydown', (e) => {
    const t = e.target;
    const typing = t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable);
    const key = e.key;

    if ((e.metaKey || e.ctrlKey) && key.toLowerCase() === 's') {
      e.preventDefault();
      actions.save();
      return;
    }
    if (key === 'Escape') {
      if (typing) return t.blur();
      if (isModalOpen()) return modalDismissible() && closeModal();
      if (closeDrawer()) return;
      const ui = store.getState().ui;
      if (ui.activeView !== 'city') return actions.openView('city');
      if (ui.activeTool !== 'select') return actions.run('ui/setTool', { tool: 'select' });
      if (ui.selection) return actions.run('ui/select', { selection: null });
      return;
    }
    if (typing || isModalOpen() || e.metaKey || e.ctrlKey || e.altKey) return;

    if (key === ' ') {
      e.preventDefault();
      actions.togglePause();
    } else if (/^[1-9]$/.test(key) && speeds[Number(key) - 1]) {
      actions.setSpeed(speeds[Number(key) - 1]);
    } else if (key === '0') {
      actions.setSpeed(0);
    } else if (key === '?' || key === 'h') {
      actions.showHelp();
    } else if (key === 'Home') {
      renderer?.setCamera(DEFAULT_CAMERA, false);
    } else if (toolKeys[key.toLowerCase()] && store.getState().ui.activeView === 'city') {
      actions.run('ui/setTool', { tool: toolKeys[key.toLowerCase()] });
    }
  });
}
