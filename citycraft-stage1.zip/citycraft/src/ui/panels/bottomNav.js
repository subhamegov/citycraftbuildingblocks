import { h, replaceChildren } from '../dom.js';
import { icon } from '../icons.js';

export const NAV_ITEMS = [
  { id: 'city', label: 'City', icon: 'city', hint: 'The physical city' },
  { id: 'services', label: 'Services', icon: 'services', hint: 'Shared platform services and municipal applications' },
  { id: 'registries', label: 'Registries', icon: 'database', hint: 'Shared records the city keeps' },
  { id: 'configure', label: 'Configure', icon: 'sliders', hint: 'City settings, ward names and saved games' },
  { id: 'insights', label: 'Insights', icon: 'chart', hint: 'Numbers, missions and the city ledger' },
];

export function createBottomNav(root, app) {
  const buttons = NAV_ITEMS.map((item) =>
    h(
      'button',
      {
        class: 'nav-item',
        'data-view': item.id,
        'data-tip': item.hint,
        onClick: () => app.actions.openView(item.id),
      },
      icon(item.icon, { size: 18 }),
      h('span', {}, item.label),
    ),
  );
  replaceChildren(
    root,
    h('div', { class: 'nav-items', role: 'tablist', 'aria-label': 'Main views' }, buttons),
    h('div', { class: 'nav-hint' }, h('kbd', {}, 'Space'), ' pause  ', h('kbd', {}, 'WASD'), ' pan  ', h('kbd', {}, 'Q'), h('kbd', {}, 'E'), ' rotate  ', h('kbd', {}, '?'), ' help'),
  );
  function update(state) {
    for (const b of buttons) {
      const on = b.dataset.view === state.ui.activeView;
      b.classList.toggle('is-active', on);
      b.setAttribute('aria-selected', String(on));
    }
  }
  return { update, slices: ['ui'] };
}
