import { h, replaceChildren } from '../dom.js';
import { icon } from '../icons.js';
import { Button } from '../components.js';
import { fmt } from '../format.js';

const SPEED_LABELS = { 0: 'Pause', 1: '1×', 2: '2×', 4: '4×' };

export function createTopBar(root, app) {
  const { config } = app;
  const cur = config.game.currency.short;

  const cityName = h('button', { class: 'city-name', 'data-tip': 'Rename your city in Configure', onClick: () => app.actions.openView('configure') });
  const stat = (iconName, label, tip) => {
    const value = h('span', { class: 'top-stat-value' });
    const el = h('div', { class: 'top-stat', 'data-tip': tip }, icon(iconName, { size: 16 }), h('div', {}, h('span', { class: 'top-stat-label' }, label), value));
    return { el, value };
  };
  const treasury = stat('coins', 'Treasury', 'Money available to spend. Every change is recorded in the ledger (Insights).');
  const population = stat('users', 'Population', 'People living in the city.');
  const happiness = stat('smile', 'Happiness', 'How residents feel about the city. Starts neutral until people move in.');
  const date = stat('calendar', 'Date', 'Simulation date. One day passes per second at 1×.');

  const speedGroup = h('div', { class: 'segmented', role: 'group', 'aria-label': 'Game speed' });
  const speedButtons = config.game.simulation.speeds.map((speed) => {
    const b = h(
      'button',
      {
        class: 'seg',
        'data-tip': speed === 0 ? 'Pause (Space)' : `Run at ${SPEED_LABELS[speed] || speed + '×'}`,
        'aria-label': speed === 0 ? 'Pause' : `Speed ${speed}`,
        onClick: () => app.actions.setSpeed(speed),
      },
      speed === 0 ? icon('pause', { size: 15 }) : speed === 1 ? icon('play', { size: 15 }) : icon('fast', { size: 15 }),
      speed === 0 ? null : h('span', {}, SPEED_LABELS[speed] || `${speed}×`),
    );
    b.dataset.speed = speed;
    speedGroup.appendChild(b);
    return b;
  });

  const saveStatus = h('span', { class: 'save-status', 'aria-live': 'polite' });

  replaceChildren(
    root,
    h('div', { class: 'brand' }, h('span', { class: 'brand-mark' }, icon('city', { size: 18 })), h('span', { class: 'brand-name' }, 'CityCraft')),
    cityName,
    h('div', { class: 'top-stats' }, treasury.el, population.el, happiness.el, date.el),
    h('div', { class: 'top-spacer' }),
    speedGroup,
    h(
      'div',
      { class: 'top-actions' },
      saveStatus,
      Button({ icon: 'save', label: 'Save', variant: 'secondary', size: 'sm', tip: 'Save your city (Ctrl+S)', onClick: () => app.actions.save() }),
      Button({ icon: 'help', variant: 'ghost', size: 'sm', tip: 'Controls and help (?)', onClick: () => app.actions.showHelp() }),
    ),
  );

  function update(state) {
    cityName.textContent = state.meta.cityName;
    treasury.value.textContent = fmt.credits(state.economy.treasury, cur);
    treasury.el.classList.toggle('is-low', state.economy.treasury < 5000);
    population.value.textContent = fmt.number(state.simulation.population);
    happiness.value.textContent = state.simulation.population > 0 ? fmt.percent(state.simulation.happiness) : 'Neutral';
    date.value.textContent = fmt.date(state.simulation.day);
    for (const b of speedButtons) {
      const on = Number(b.dataset.speed) === state.simulation.speed;
      b.classList.toggle('is-active', on);
      b.setAttribute('aria-pressed', String(on));
    }
    root.classList.toggle('is-paused', state.simulation.speed === 0);
  }

  function setSaveStatus(text) {
    saveStatus.textContent = text;
  }

  return { update, setSaveStatus, slices: ['meta', 'economy', 'simulation'] };
}
