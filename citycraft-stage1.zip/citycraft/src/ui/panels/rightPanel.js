// Inspector: city overview, a selected plot, or a selected ward.
// Shows the physical thing and the digital records that describe it side by side.

import { h, replaceChildren } from '../dom.js';
import { icon } from '../icons.js';
import { Button, Card, KeyValue, Badge, Dot, SectionTitle } from '../components.js';
import { getTile, plotStatus, tileId } from '../../physical/tiles.js';
import { wardRecordByCode } from '../../registries/index.js';
import { wardSummaries } from '../../analytics/metrics.js';

const STATUS_TONE = { open: 'success', wooded: 'warning', water: 'info', unbuildable: 'neutral', developed: 'accent' };

export function createRightPanel(root, app) {
  const { config } = app;
  const cur = config.game.currency.short;
  const wardColor = (code) => config.wards.wards.find((w) => w.code === code)?.color;

  function overview(state) {
    const wards = wardSummaries(state, config);
    return [
      h('div', { class: 'inspector-head' }, h('div', { class: 'eyebrow' }, 'City overview'), h('h2', {}, state.meta.cityName)),
      h('p', { class: 'muted' }, 'Click any plot on the map to inspect it, or open a ward below.'),
      SectionTitle('Wards'),
      h(
        'div',
        { class: 'ward-list' },
        wards.map((w) =>
          h(
            'button',
            { class: 'ward-row', onClick: () => app.actions.selectWard(w.code), 'data-tip': `Inspect ${w.name}` },
            Dot(w.color),
            h('div', { class: 'ward-row-main' }, h('strong', {}, w.name), h('span', { class: 'muted small' }, `${w.code} · ${w.open} open plots · ${w.wooded} wooded`)),
            icon('pin', { size: 16 }),
          ),
        ),
      ),
      Card({
        title: 'Two cities in one',
        icon: 'link',
        children: h(
          'p',
          { class: 'small' },
          'Everything you build here will also exist as records in the Registries view. One plot, one record, shared by every service that needs it.',
        ),
      }),
    ];
  }

  function tileView(state, sel) {
    const tile = getTile(state.world, sel.x, sel.y);
    if (!tile) return overview(state);
    const status = plotStatus(config, tile);
    const ward = wardRecordByCode(state.registries, tile.ward);
    const terrain = config.terrain.types[tile.terrain];
    const clear = app.store.canDispatch('world/clearTree', { x: tile.x, y: tile.y });
    const plant = app.store.canDispatch('world/plantTree', { x: tile.x, y: tile.y });
    const action = (label, iconName, type, check, cost) =>
      h(
        'div',
        { class: 'action-row' },
        Button({
          label: `${label} · ${cost} ${cur}`,
          icon: iconName,
          variant: 'secondary',
          block: true,
          disabled: !check.ok,
          onClick: () => app.actions.run(type, { x: tile.x, y: tile.y }),
        }),
        !check.ok ? h('span', { class: 'action-reason' }, check.error) : null,
      );

    return [
      h(
        'div',
        { class: 'inspector-head' },
        h('div', { class: 'eyebrow' }, 'Plot'),
        h('h2', {}, tileId(tile.x, tile.y)),
        Badge(status.label, STATUS_TONE[status.key] || 'neutral'),
      ),
      Card({
        title: 'On the ground',
        icon: 'map',
        children: KeyValue([
          ['Ward', h('button', { class: 'link', onClick: () => app.actions.selectWard(tile.ward) }, Dot(wardColor(tile.ward)), ward?.name ?? tile.ward)],
          ['Terrain', terrain?.label ?? tile.terrain],
          ['Trees', tile.tree ? config.terrain.trees[tile.tree]?.label ?? tile.tree : 'None'],
          ['Grid position', `${tile.x}, ${tile.y}`],
        ]),
      }),
      Card({
        title: 'In the records',
        icon: 'record',
        children: [
          KeyValue([
            ['Boundary', ward ? h('span', { class: 'mono' }, ward.id) : 'Missing'],
            ['Property', h('span', { class: 'muted' }, 'None yet')],
            ['Address', h('span', { class: 'muted' }, 'None yet')],
          ]),
          h('p', { class: 'small muted' }, 'A property record and address are created when this plot is developed and connected to a road.'),
        ],
      }),
      SectionTitle('Actions'),
      h(
        'div',
        { class: 'stack-sm' },
        action('Clear trees', 'axe', 'world/clearTree', clear, config.game.costs.clearTree),
        action('Plant a tree', 'tree', 'world/plantTree', plant, config.game.costs.plantTree),
        Button({ label: 'Close', variant: 'ghost', block: true, onClick: () => app.actions.run('ui/select', { selection: null }) }),
      ),
    ];
  }

  function wardView(state, sel) {
    const record = wardRecordByCode(state.registries, sel.code);
    const summary = wardSummaries(state, config).find((w) => w.code === sel.code);
    const cfg = config.wards.wards.find((w) => w.code === sel.code);
    if (!record || !summary) return overview(state);
    return [
      h(
        'div',
        { class: 'inspector-head' },
        h('div', { class: 'eyebrow' }, Dot(cfg.color), `Ward ${record.code}`),
        h('h2', {}, record.name),
      ),
      h('p', { class: 'muted' }, record.description),
      Card({
        title: 'Land',
        icon: 'map',
        children: KeyValue([
          ['Area', `${summary.tiles} plots`],
          ['Open plots', String(summary.open)],
          ['Wooded', String(summary.wooded)],
          ['Water and shore', String(summary.water + summary.shore)],
          ['Residents', String(summary.population)],
        ]),
      }),
      Card({
        title: 'Boundary record',
        icon: 'record',
        children: [
          KeyValue([
            ['Record ID', h('span', { class: 'mono' }, record.id)],
            ['Version', String(record.version)],
            ['Extent', `x ${record.bounds.minX} to ${record.bounds.maxX}, y ${record.bounds.minY} to ${record.bounds.maxY}`],
          ]),
          h('p', { class: 'small muted' }, 'Every plot in this ward points to this one record. Rename the ward once and every screen updates.'),
        ],
      }),
      h(
        'div',
        { class: 'stack-sm' },
        Button({ label: 'Rename ward', icon: 'sliders', variant: 'secondary', block: true, onClick: () => app.actions.openView('configure') }),
        Button({ label: 'View in Registries', icon: 'database', variant: 'secondary', block: true, onClick: () => app.actions.openView('registries') }),
        Button({ label: 'Back to overview', variant: 'ghost', block: true, onClick: () => app.actions.run('ui/select', { selection: null }) }),
      ),
    ];
  }

  let last = '';
  function update(state) {
    const sel = state.ui.selection;
    // Re-render when the selection, the world, the registries or money change.
    const sig = JSON.stringify([
      sel,
      app.store.sliceRevision('world'),
      app.store.sliceRevision('registries'),
      app.store.sliceRevision('economy'),
      state.meta.cityName,
    ]);
    if (sig === last) return;
    last = sig;
    let content;
    if (sel?.kind === 'tile') content = tileView(state, sel);
    else if (sel?.kind === 'ward') content = wardView(state, sel);
    else content = overview(state);
    replaceChildren(root, h('div', { class: 'panel-scroll' }, content));
  }

  return { update, slices: ['ui', 'world', 'registries', 'economy', 'meta'] };
}
