// Construction tools, locked build categories, map layers and missions.

import { h, replaceChildren } from '../dom.js';
import { icon } from '../icons.js';
import { SectionTitle, Toggle, Progress } from '../components.js';
import { missionProgress } from '../../analytics/missions.js';

export function createLeftPanel(root, app) {
  const { config } = app;
  const cur = config.game.currency.short;

  function render(state) {
    const tools = config.construction.tools.map((tool) => {
      const cost = tool.costKey ? config.game.costs[tool.costKey] : null;
      const active = state.ui.activeTool === tool.id;
      return h(
        'button',
        {
          class: ['tool', active && 'is-active'],
          'aria-pressed': String(active),
          'data-tip': `${tool.hint} (${tool.shortcut})`,
          onClick: () => app.actions.run('ui/setTool', { tool: tool.id }),
        },
        h('span', { class: 'tool-icon' }, icon(tool.icon, { size: 18 })),
        h('span', { class: 'tool-label' }, tool.label),
        cost ? h('span', { class: 'tool-cost' }, `${cost} ${cur}`) : h('kbd', {}, tool.shortcut),
      );
    });

    const categories = config.construction.categories.map((cat) =>
      h(
        'div',
        { class: 'locked-tool', 'aria-disabled': 'true', 'data-tip': `${cat.summary} Not available yet.` },
        h('span', { class: 'tool-icon' }, icon(cat.icon, { size: 18 })),
        h('span', { class: 'tool-label' }, cat.label),
        h('span', { class: 'lock' }, icon('lock', { size: 14 })),
      ),
    );

    const layers = [
      Toggle({ label: 'Ward boundaries', checked: state.ui.overlays.wards, onChange: (on) => app.actions.run('ui/setOverlay', { overlay: 'wards', on }) }),
      Toggle({ label: 'Open plots', checked: state.ui.overlays.plots, tip: 'Outline plots that are ready to build on', onChange: (on) => app.actions.run('ui/setOverlay', { overlay: 'plots', on }) }),
    ];

    const defs = config.missions.missions;
    const doneCount = Object.keys(state.missions.completed).length;
    const missions = defs.map((m) => {
      const done = m.id in state.missions.completed;
      const p = done ? { value: m.goal.target, target: m.goal.target } : missionProgress(state, m);
      return h(
        'li',
        { class: ['mission', done && 'is-done'], 'data-tip': m.description },
        h('span', { class: 'mission-check' }, done ? icon('check', { size: 13 }) : null),
        h('div', { class: 'mission-text' }, h('span', {}, m.title), !done && p.target > 1 ? Progress(p.value, p.target) : null),
        !done && p.target > 1 ? h('span', { class: 'mission-count' }, `${p.value}/${p.target}`) : null,
      );
    });

    replaceChildren(
      root,
      h(
        'div',
        { class: 'panel-scroll' },
        SectionTitle('Tools'),
        h('div', { class: 'tool-list' }, tools),
        SectionTitle('Build', h('span', { class: 'muted small' }, 'Locked')),
        h('div', { class: 'tool-list' }, categories),
        SectionTitle('Map layers'),
        h('div', { class: 'stack-sm' }, layers),
        SectionTitle('First week in office', h('span', { class: 'muted small' }, `${doneCount}/${defs.length}`)),
        h('ul', { class: 'mission-list' }, missions),
      ),
    );
  }

  // Rebuild only when something visible actually changed.
  let last = '';
  function update(state) {
    const sig = JSON.stringify([
      state.ui.activeTool,
      state.ui.overlays,
      state.missions.completed,
      config.missions.missions.map((m) => missionProgress(state, m).value),
    ]);
    if (sig === last) return;
    last = sig;
    render(state);
  }

  return { update, slices: ['ui', 'missions', 'simulation'] };
}
