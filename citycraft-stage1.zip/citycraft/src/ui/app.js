// The interface shell. Mounts the panels and views, and re-renders only the
// parts whose state slices changed.

import { $, h, replaceChildren } from './dom.js';
import { REPLACE } from '../core/store.js';
import { notify, installTooltips } from './overlays.js';
import { createTopBar } from './panels/topBar.js';
import { createLeftPanel } from './panels/leftPanel.js';
import { createRightPanel } from './panels/rightPanel.js';
import { createBottomNav } from './panels/bottomNav.js';
import { createServicesView } from './views/servicesView.js';
import { createRegistriesView } from './views/registriesView.js';
import { createConfigureView } from './views/configureView.js';
import { createInsightsView } from './views/insightsView.js';

export function mountApp({ store, config, persistence, actions, diagnostics, onViewChange }) {
  installTooltips();
  const sheet = $('#sheet');
  const appEl = $('#app');

  const app = { store, config, persistence, actions, notify, diagnostics, refreshView: () => renderSheet(store.getState(), true) };

  const topBar = createTopBar($('#topbar'), app);
  const panels = [topBar, createLeftPanel($('#left-panel'), app), createRightPanel($('#right-panel'), app), createBottomNav($('#bottom-nav'), app)];
  const views = Object.fromEntries([createServicesView(app), createRegistriesView(app), createConfigureView(app), createInsightsView(app)].map((v) => [v.id, v]));

  let currentView = null;

  function renderSheet(state, force = false) {
    const view = views[state.ui.activeView];
    if (!view) return;
    // Never rebuild a form while the player is typing in it.
    if (!force && sheet.contains(document.activeElement) && /INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName)) return;
    const scroll = sheet.scrollTop;
    replaceChildren(sheet, h('div', { class: 'sheet-inner' }, view.render(state)));
    sheet.scrollTop = scroll;
  }

  function applyView(state) {
    const viewId = state.ui.activeView;
    if (viewId === currentView) return false;
    currentView = viewId;
    const isCity = viewId === 'city';
    appEl.dataset.view = viewId;
    sheet.hidden = isCity;
    if (!isCity) {
      sheet.scrollTop = 0;
      renderSheet(state, true);
    }
    onViewChange?.(viewId);
    return true;
  }

  function updateAll(state) {
    panels.forEach((p) => p.update(state));
    applyView(state);
    if (state.ui.activeView !== 'city') renderSheet(state, true);
  }

  store.subscribe((record, state) => {
    if (!record.ok) return;
    if (record.type === REPLACE) {
      currentView = null;
      updateAll(state);
      return;
    }
    const touched = new Set(record.touched);
    for (const p of panels) if (p.slices.some((s) => touched.has(s))) p.update(state);
    const switched = touched.has('ui') && applyView(state);
    const view = views[state.ui.activeView];
    if (!switched && view && view.slices.some((s) => touched.has(s))) renderSheet(state);

    for (const ev of record.events) {
      if (ev.type === 'mission.completed') notify(ev.title, 'success', { title: 'Mission complete', timeout: 4000 });
    }
  });

  updateAll(store.getState());

  return {
    app,
    setSaveStatus: (t) => topBar.setSaveStatus(t),
  };
}
