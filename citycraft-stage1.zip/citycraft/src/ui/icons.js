// Inline stroke icons (24 x 24). Kept local so the game works offline.

const PATHS = {
  cursor: 'M5 3l6.5 17 2.4-7.2L21 10.4z',
  axe: 'M14.5 3.5l6 6-2.8 2.8-6-6z M12.6 7.2L3.5 16.3l4.2 4.2 9.1-9.1',
  tree: 'M12 2.5l6 8.5h-3.5l4.5 6.5H5l4.5-6.5H6z M12 17.5v4',
  road: 'M8 3L4 21 M16 3l4 18 M12 4v2.5 M12 10.5v3 M12 17.5v3',
  grid: 'M3.5 3.5h17v17h-17z M3.5 9.2h17 M3.5 14.8h17 M9.2 3.5v17 M14.8 3.5v17',
  bolt: 'M13 2.5L4.5 14H11l-1 7.5L19.5 10H13z',
  landmark: 'M3 21h18 M5 21v-9 M19 21v-9 M9.7 21v-9 M14.3 21v-9 M2.5 10L12 4l9.5 6z',
  lock: 'M6 11h12v10H6z M8.5 11V7.5a3.5 3.5 0 0 1 7 0V11',
  play: 'M7.5 4.5l12 7.5-12 7.5z',
  pause: 'M7 4.5h3.5v15H7z M13.5 4.5H17v15h-3.5z',
  fast: 'M3 5.5l8 6.5-8 6.5z M12 5.5l8 6.5-8 6.5z',
  save: 'M5 3.5h11l3.5 3.5v13.5H5z M8 3.5v5.5h7.5V3.5 M8 20.5v-6.5h8v6.5',
  folder: 'M3 6.5h6.5l2 2H21v11.5H3z',
  reset: 'M4 4.5v5.5h5.5 M4.6 15a8 8 0 1 0 1.9-8.3L4 10',
  help: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z M9.6 9.2a2.5 2.5 0 1 1 3.5 2.3c-.7.3-1.1.9-1.1 1.7v.3 M12 16.8v.2',
  city: 'M3 21h18 M5 21V9.5l6-3V21 M11 21V3.5l8 4V21 M14 10h2 M14 13.5h2 M14 17h2 M7.5 13h1 M7.5 16.5h1',
  services: 'M12 3l9 4.8-9 4.8-9-4.8z M3 12.2l9 4.8 9-4.8 M3 16.4l9 4.8 9-4.8',
  database: 'M4 6c0-1.7 3.6-3 8-3s8 1.3 8 3-3.6 3-8 3-8-1.3-8-3z M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6 M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3',
  sliders: 'M4 6.5h9 M17 6.5h3 M4 12h3 M11 12h9 M4 17.5h11 M19 17.5h1 M15 4.5v4 M9 10v4 M17 15.5v4',
  chart: 'M4 20V11 M10 20V5 M16 20v-6.5 M3 20.5h18',
  coins: 'M12 4c4.4 0 8 1.3 8 3s-3.6 3-8 3-8-1.3-8-3 3.6-3 8-3z M4 7v5c0 1.7 3.6 3 8 3s8-1.3 8-3V7 M4 12v5c0 1.7 3.6 3 8 3s8-1.3 8-3v-5',
  users: 'M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M2.5 21v-.5a6.5 6.5 0 0 1 13 0v.5 M16 3.6a4 4 0 0 1 0 7.4 M21.5 21v-.5a6.5 6.5 0 0 0-3.8-5.9',
  smile: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z M8 14.5s1.5 2 4 2 4-2 4-2 M9 9.5v.1 M15 9.5v.1',
  calendar: 'M4 5.5h16v15H4z M4 10h16 M8 3v4 M16 3v4',
  check: 'M5 12.5l4.5 4.5L19 7.5',
  close: 'M6 6l12 12 M18 6L6 18',
  map: 'M3 6.5l6-3 6 3 6-3v14l-6 3-6-3-6 3z M9 3.5v14 M15 6.5v14',
  eye: 'M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
  download: 'M12 3.5v12 M7 10.5l5 5 5-5 M4 20.5h16',
  upload: 'M12 15.5v-12 M7 8.5l5-5 5 5 M4 20.5h16',
  info: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z M12 16.5v-5 M12 8v.1',
  pin: 'M12 21s-7-6.2-7-11.5a7 7 0 0 1 14 0C19 14.8 12 21 12 21z M12 11.5a2 2 0 1 0 0-4 2 2 0 0 0 0 4z',
  flag: 'M5 21V4 M5 4.5h11l-2 4 2 4H5',
  link: 'M10 14a4.5 4.5 0 0 0 6.4 0l3-3a4.5 4.5 0 0 0-6.4-6.4l-1 1 M14 10a4.5 4.5 0 0 0-6.4 0l-3 3a4.5 4.5 0 0 0 6.4 6.4l1-1',
  rotateLeft: 'M3.5 4.5v5h5 M4 9.5a8.5 8.5 0 1 1-.3 5',
  rotateRight: 'M20.5 4.5v5h-5 M20 9.5a8.5 8.5 0 1 0 .3 5',
  plus: 'M12 5v14 M5 12h14',
  minus: 'M5 12h14',
  home: 'M3.5 11L12 4l8.5 7 M6 9.5V20h12V9.5',
  water: 'M12 3s6 7 6 11a6 6 0 0 1-12 0c0-4 6-11 6-11z',
  record: 'M6 3.5h9l3.5 3.5v13.5H6z M9 11h6 M9 14.5h6 M9 18h3',
};

const NS = 'http://www.w3.org/2000/svg';

export function icon(name, { size = 18, className = 'icon' } = {}) {
  const svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('width', size);
  svg.setAttribute('height', size);
  svg.setAttribute('fill', 'none');
  svg.setAttribute('stroke', 'currentColor');
  svg.setAttribute('stroke-width', '1.8');
  svg.setAttribute('stroke-linecap', 'round');
  svg.setAttribute('stroke-linejoin', 'round');
  svg.setAttribute('aria-hidden', 'true');
  svg.setAttribute('class', className);
  const path = document.createElementNS(NS, 'path');
  path.setAttribute('d', PATHS[name] || PATHS.info);
  svg.appendChild(path);
  return svg;
}
