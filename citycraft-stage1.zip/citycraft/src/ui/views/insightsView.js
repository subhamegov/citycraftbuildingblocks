// Insights: key numbers, ward land use, missions, ledger and journal.

import { h } from '../dom.js';
import { Card, Stat, Table, Progress, Badge, Dot, KeyValue } from '../components.js';
import { cityMetrics, wardSummaries } from '../../analytics/metrics.js';
import { missionProgress } from '../../analytics/missions.js';
import { fmt } from '../format.js';

export function createInsightsView(app) {
  const { config } = app;
  const cur = config.game.currency.short;

  function render(state) {
    const m = cityMetrics(state, config);
    const wards = wardSummaries(state, config);
    const diag = app.diagnostics?.();

    const missionRows = config.missions.missions.map((mission) => {
      const done = mission.id in state.missions.completed;
      const p = done ? { value: mission.goal.target, target: mission.goal.target } : missionProgress(state, mission);
      return { mission, done, p };
    });

    return [
      h('div', { class: 'sheet-intro' }, h('h1', {}, 'Insights'), h('p', {}, 'What is happening in your city, from the same records the services use.')),
      h(
        'div',
        { class: 'stat-row' },
        Stat({ label: 'Treasury', value: fmt.credits(m.treasury, cur), icon: 'coins' }),
        Stat({ label: 'Population', value: fmt.number(m.population), icon: 'users' }),
        Stat({ label: 'Open plots', value: fmt.number(m.land.open), icon: 'grid', hint: 'Buildable land with nothing on it' }),
        Stat({ label: 'Days in office', value: fmt.number(m.day), icon: 'calendar' }),
      ),
      h(
        'div',
        { class: 'sheet-grid' },
        Card({
          title: 'Land by ward',
          icon: 'map',
          className: 'span-2',
          children: Table({
            columns: [
              { label: 'Ward', render: (w) => h('span', { class: 'inline' }, Dot(w.color), w.name) },
              { label: 'Plots', align: 'right', key: 'tiles' },
              { label: 'Open', align: 'right', key: 'open' },
              { label: 'Wooded', align: 'right', key: 'wooded' },
              { label: 'Water', align: 'right', render: (w) => String(w.water) },
              { label: 'Residents', align: 'right', key: 'population' },
            ],
            rows: wards,
          }),
        }),
        Card({
          title: 'Missions',
          icon: 'flag',
          children: h(
            'ul',
            { class: 'mission-table' },
            missionRows.map(({ mission, done, p }) =>
              h(
                'li',
                {},
                h('div', { class: 'row-between' }, h('strong', {}, mission.title), done ? Badge('Done', 'success') : h('span', { class: 'muted small' }, `${p.value}/${p.target}`)),
                h('p', { class: 'small muted' }, mission.description),
                done ? null : Progress(p.value, p.target),
              ),
            ),
          ),
        }),
        Card({
          title: 'Ledger',
          subtitle: 'Every change to the treasury, newest first.',
          icon: 'coins',
          className: 'span-2',
          children: Table({
            columns: [
              { label: 'Ref', render: (r) => h('span', { class: 'mono' }, r.id) },
              { label: 'Date', render: (r) => fmt.date(r.day) },
              { label: 'What', key: 'memo' },
              { label: 'Amount', align: 'right', render: (r) => h('span', { class: r.amount < 0 ? 'text-danger' : 'text-success' }, fmt.signedCredits(r.amount, cur)) },
              { label: 'Balance', align: 'right', render: (r) => fmt.credits(r.balance, cur) },
            ],
            rows: state.economy.ledger.slice(-12).reverse(),
            empty: 'No spending yet. Clearing or planting trees will show up here.',
          }),
        }),
        Card({
          title: 'City journal',
          icon: 'record',
          children: h(
            'ul',
            { class: 'journal' },
            state.simulation.journal
              .slice(-10)
              .reverse()
              .map((j) => h('li', { class: `j-${j.kind}` }, h('span', { class: 'muted small' }, fmt.date(j.day)), h('span', {}, j.text))),
          ),
        }),
        state.economy.months.length
          ? Card({
              title: 'Monthly accounts',
              icon: 'chart',
              className: 'span-2',
              children: Table({
                columns: [
                  { label: 'Month', key: 'label' },
                  { label: 'Income', align: 'right', render: (r) => fmt.credits(r.income, cur) },
                  { label: 'Spending', align: 'right', render: (r) => fmt.credits(r.spending, cur) },
                  { label: 'Closing balance', align: 'right', render: (r) => fmt.credits(r.closingBalance, cur) },
                ],
                rows: state.economy.months.slice(-6).reverse(),
              }),
            })
          : null,
        diag
          ? Card({
              title: 'Engine check',
              subtitle: 'Objects drawn from the current state. Loading a save rebuilds these, it never adds to them.',
              icon: 'info',
              children: KeyValue([
                ['Plots drawn', `${diag.land + diag.water} of ${state.world.width * state.world.height}`],
                ['Trees drawn', fmt.number(diag.trees)],
                ['Ward labels', String(diag.wardLabels)],
                ['Scene objects', fmt.number(diag.sceneObjects)],
                ['Draw calls last frame', fmt.number(diag.drawCalls)],
              ]),
            })
          : null,
      ),
    ];
  }

  return { id: 'insights', render, slices: ['economy', 'simulation', 'missions', 'world', 'registries'] };
}
