// Registries: the shared records behind the physical city.

import { h } from '../dom.js';
import { Card, Tabs, Table, EmptyState, Button, KeyValue, Dot } from '../components.js';
import { listRecords, countRecords } from '../../registries/registry.js';
import { openDrawer, closeDrawer } from '../overlays.js';
import { fmt } from '../format.js';

export function createRegistriesView(app) {
  const { config } = app;
  let activeTab = 'boundaries';

  function showRecord(record) {
    openDrawer({
      title: `${record.name || record.id}`,
      body: [
        KeyValue(
          Object.entries(record)
            .filter(([k]) => !['links', 'bounds'].includes(k))
            .map(([k, v]) => [k, h('span', { class: k === 'id' ? 'mono' : '' }, String(v))]),
        ),
        record.bounds
          ? KeyValue([['bounds', `x ${record.bounds.minX}–${record.bounds.maxX}, y ${record.bounds.minY}–${record.bounds.maxY}`]])
          : null,
        h('h4', { class: 'drawer-sub' }, 'Linked records'),
        Object.keys(record.links || {}).length
          ? KeyValue(Object.entries(record.links).map(([rel, ids]) => [rel, ids.join(', ')]))
          : h('p', { class: 'muted small' }, 'No other records link here yet. Properties, addresses and residents will point to this record as the city grows.'),
        record.code
          ? Button({
              label: 'Show on map',
              icon: 'pin',
              variant: 'primary',
              onClick: () => {
                closeDrawer();
                app.actions.selectWard(record.code);
              },
            })
          : null,
      ],
    });
  }

  function render(state) {
    const defs = config.registries.registries;
    const def = defs.find((d) => d.id === activeTab) || defs[0];
    const registry = state.registries[def.id];
    const records = listRecords(registry);
    const wardColor = (code) => config.wards.wards.find((w) => w.code === code)?.color;

    let body;
    if (def.id === 'boundaries') {
      body = Table({
        columns: [
          { label: 'Record ID', render: (r) => h('span', { class: 'mono' }, r.id) },
          { label: 'Ward', render: (r) => h('span', { class: 'inline' }, Dot(wardColor(r.code)), `${r.name} (${r.code})`) },
          { label: 'Area', align: 'right', render: (r) => `${r.areaTiles} plots` },
          { label: 'Version', align: 'right', render: (r) => String(r.version) },
          { label: 'Last updated', render: (r) => fmt.date(r.updatedDay) },
          {
            label: '',
            align: 'right',
            render: (r) =>
              Button({
                label: 'Show on map',
                size: 'sm',
                variant: 'ghost',
                onClick: (e) => {
                  e.stopPropagation();
                  app.actions.selectWard(r.code);
                },
              }),
          },
        ],
        rows: records,
        onRowClick: showRecord,
      });
    } else if (!records.length) {
      body = EmptyState({ icon: 'record', title: 'No records yet', text: def.fillsWhen });
    } else {
      body = Table({
        columns: [
          { label: 'Record ID', render: (r) => h('span', { class: 'mono' }, r.id) },
          { label: 'Name', render: (r) => r.name || '' },
          { label: 'Version', align: 'right', render: (r) => String(r.version) },
        ],
        rows: records,
        onRowClick: showRecord,
      });
    }

    return [
      h(
        'div',
        { class: 'sheet-intro' },
        h('h1', {}, 'Registries'),
        h(
          'p',
          {},
          'The city keeps one shared record for each real thing: a ward, a property, an address, a person. Services read and update these records instead of keeping their own copies, so the city never holds two versions of the truth.',
        ),
      ),
      Tabs({
        tabs: defs.map((d) => ({ id: d.id, label: d.label, count: countRecords(state.registries[d.id]) })),
        active: def.id,
        label: 'Registries',
        onChange: (id) => {
          activeTab = id;
          app.refreshView();
        },
      }),
      Card({ title: def.label, subtitle: def.summary, icon: 'database', children: body }),
    ];
  }

  return { id: 'registries', render, slices: ['registries'] };
}
