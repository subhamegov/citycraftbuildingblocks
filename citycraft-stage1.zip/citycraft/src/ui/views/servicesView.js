// Services: the shared platform parts and the municipal applications built
// from them. Read-only in stage 1.

import { h } from '../dom.js';
import { icon } from '../icons.js';
import { Card, Badge } from '../components.js';
import { serviceStatus } from '../../platform/index.js';

export function createServicesView(app) {
  const { config } = app;
  const label = (id) => config.platformServices.services.find((s) => s.id === id)?.label ?? id;

  function render(state) {
    const platform = config.platformServices.services.map((svc) =>
      h(
        'article',
        { class: 'tile-card' },
        h('div', { class: 'tile-card-top' }, h('span', { class: 'tile-card-icon' }, icon('services', { size: 18 })), Badge(serviceStatus(state, svc.id) === 'active' ? 'Running' : 'Not set up', 'neutral')),
        h('h4', {}, svc.label),
        h('p', {}, svc.summary),
      ),
    );
    const apps = config.municipalApps.applications.map((a) =>
      h(
        'article',
        { class: 'tile-card' },
        h('div', { class: 'tile-card-top' }, h('span', { class: 'tile-card-icon alt' }, icon('landmark', { size: 18 })), Badge('Locked', 'neutral')),
        h('h4', {}, a.label),
        h('p', {}, a.summary),
        h('div', { class: 'chips' }, h('span', { class: 'chips-label' }, 'Built from'), a.uses.map((u) => h('span', { class: 'chip' }, label(u)))),
      ),
    );
    return [
      h(
        'div',
        { class: 'sheet-intro' },
        h('h1', {}, 'Services'),
        h(
          'p',
          {},
          'Residents do not see departments. They see a tax bill, a permit, a water connection. Each of those is built from the same few shared parts. Set the parts up once and every new service gets cheaper to launch.',
        ),
      ),
      Card({
        title: 'Shared platform services',
        subtitle: 'The common parts every municipal service relies on. None are running yet.',
        icon: 'services',
        children: h('div', { class: 'tile-grid' }, platform),
      }),
      Card({
        title: 'Municipal applications',
        subtitle: 'What residents and businesses actually use. Each one lists the shared parts it needs.',
        icon: 'landmark',
        children: h('div', { class: 'tile-grid' }, apps),
      }),
    ];
  }

  return { id: 'services', render, slices: ['platform', 'municipalServices'] };
}
