// Configure: city settings, ward names, autosave and saved games.

import { h } from '../dom.js';
import { Card, Field, TextInput, Select, Toggle, Button, KeyValue, Dot } from '../components.js';
import { wardName } from '../../registries/index.js';
import { STATE_VERSION } from '../../state/schema.js';
import { fmt } from '../format.js';

export function createConfigureView(app) {
  const { config } = app;

  function slotInfo(slot) {
    const info = app.persistence.info(slot);
    if (!info) return h('span', { class: 'muted' }, 'Empty');
    if (info.damaged) return h('span', { class: 'text-danger' }, 'Damaged');
    return h('span', {}, `${info.cityName}, ${fmt.date(info.day)} · saved ${fmt.when(info.savedAt)} · ${fmt.bytes(info.bytes)}`);
  }

  function render(state) {
    const s = state.ui.settings;
    return [
      h('div', { class: 'sheet-intro' }, h('h1', {}, 'Configure'), h('p', {}, 'Change how your city is named and how your progress is kept.')),
      h(
        'div',
        { class: 'sheet-grid' },
        Card({
          title: 'City',
          icon: 'city',
          children: Field({
            label: 'City name',
            hint: 'Shown in the top bar and on saved games.',
            id: 'cfg-city-name',
            control: TextInput({
              id: 'cfg-city-name',
              value: state.meta.cityName,
              maxLength: 32,
              onCommit: (v, input) => {
                if (v.trim() === state.meta.cityName) return;
                const r = app.actions.run('city/rename', { name: v });
                if (!r.ok) input.value = state.meta.cityName;
                else app.notify('City renamed.', 'success');
              },
            }),
          }),
        }),
        Card({
          title: 'Ward names',
          subtitle: 'Changes the boundary record. Every screen that shows the ward updates.',
          icon: 'map',
          children: h(
            'div',
            { class: 'stack' },
            config.wards.wards.map((w) =>
              Field({
                label: h('span', { class: 'inline' }, Dot(w.color), `Ward ${w.code}`),
                id: `cfg-ward-${w.code}`,
                control: TextInput({
                  id: `cfg-ward-${w.code}`,
                  value: wardName(state.registries, w.code),
                  maxLength: 28,
                  onCommit: (v, input) => {
                    const current = wardName(state.registries, w.code);
                    if (v.trim() === current) return;
                    const r = app.actions.run('registry/renameWard', { code: w.code, name: v });
                    if (!r.ok) input.value = current;
                    else app.notify(`Ward ${w.code} is now ${v.trim()}.`, 'success');
                  },
                }),
              }),
            ),
          ),
        }),
        Card({
          title: 'Autosave',
          icon: 'save',
          children: h(
            'div',
            { class: 'stack' },
            Toggle({ label: 'Save automatically while the clock runs', checked: s.autosave, onChange: (on) => app.actions.run('settings/update', { autosave: on }) }),
            Field({
              label: 'Autosave every',
              id: 'cfg-autosave',
              control: Select({
                id: 'cfg-autosave',
                value: s.autosaveEveryDays,
                options: config.game.autosave.options.map((d) => ({ value: d, label: d === 1 ? 'day' : `${d} days` })),
                onChange: (v) => app.actions.run('settings/update', { autosaveEveryDays: Number(v) }),
              }),
            }),
          ),
        }),
        Card({
          title: 'Saved games',
          subtitle: app.persistence.persistent ? 'Stored in this browser.' : 'This browser blocks storage. Saves will be lost when you close the page. Use Export to keep a copy.',
          icon: 'folder',
          children: [
            KeyValue([
              ['Manual save', slotInfo('manual')],
              ['Autosave', slotInfo('auto')],
            ]),
            h(
              'div',
              { class: 'button-row' },
              Button({ label: 'Save now', icon: 'save', variant: 'primary', onClick: () => app.actions.save() }),
              Button({ label: 'Load save', icon: 'folder', disabled: !app.persistence.info('manual'), onClick: () => app.actions.load('manual') }),
              Button({ label: 'Load autosave', icon: 'folder', disabled: !app.persistence.info('auto'), onClick: () => app.actions.load('auto') }),
            ),
            h(
              'div',
              { class: 'button-row' },
              Button({ label: 'Export file', icon: 'download', variant: 'ghost', onClick: () => app.actions.exportSave() }),
              Button({ label: 'Import file', icon: 'upload', variant: 'ghost', onClick: () => app.actions.importSave() }),
              Button({ label: 'Start a new city', icon: 'reset', variant: 'danger-ghost', onClick: () => app.actions.newCity() }),
            ),
          ],
        }),
        Card({
          title: 'About this city',
          icon: 'info',
          children: KeyValue([
            ['Save format', `Version ${STATE_VERSION}`],
            ['Map seed', h('span', { class: 'mono' }, String(state.meta.seed))],
            ['Changes made', fmt.number(state.meta.revision)],
            ['Manual saves', String(state.meta.manualSaves)],
          ]),
        }),
      ),
    ];
  }

  return { id: 'configure', render, slices: ['meta', 'registries', 'ui'] };
}
