// Reusable interface parts. Every view is assembled from these so the game
// keeps one consistent look as later stages add screens.

import { h } from './dom.js';
import { icon } from './icons.js';

export function Button({ label, icon: iconName, variant = 'secondary', size = 'md', onClick, disabled, tip, pressed, type = 'button', ariaLabel, block } = {}) {
  return h(
    'button',
    {
      type,
      class: ['btn', `btn-${variant}`, `btn-${size}`, !label && 'btn-icon', block && 'btn-block'],
      onClick,
      disabled,
      'data-tip': tip,
      'aria-label': ariaLabel || (!label ? tip : undefined),
      'aria-pressed': pressed === undefined ? undefined : String(Boolean(pressed)),
    },
    iconName ? icon(iconName, { size: size === 'sm' ? 16 : 18 }) : null,
    label ? h('span', {}, label) : null,
  );
}

export function Card({ title, subtitle, icon: iconName, actions, children, className, flush } = {}) {
  return h(
    'section',
    { class: ['card', flush && 'card-flush', className] },
    title || actions
      ? h(
          'header',
          { class: 'card-header' },
          h(
            'div',
            { class: 'card-heading' },
            iconName ? h('span', { class: 'card-icon' }, icon(iconName, { size: 16 })) : null,
            h('div', {}, title ? h('h3', { class: 'card-title' }, title) : null, subtitle ? h('p', { class: 'card-subtitle' }, subtitle) : null),
          ),
          actions ? h('div', { class: 'card-actions' }, actions) : null,
        )
      : null,
    h('div', { class: 'card-body' }, children),
  );
}

export function Badge(text, tone = 'neutral') {
  return h('span', { class: ['badge', `badge-${tone}`] }, text);
}

export function Dot(color) {
  return h('span', { class: 'dot', style: { background: color } });
}

export function Stat({ label, value, icon: iconName, hint, tone }) {
  return h(
    'div',
    { class: ['stat', tone && `stat-${tone}`], 'data-tip': hint },
    iconName ? h('span', { class: 'stat-icon' }, icon(iconName, { size: 18 })) : null,
    h('div', {}, h('div', { class: 'stat-label' }, label), h('div', { class: 'stat-value' }, value)),
  );
}

export function KeyValue(rows) {
  return h(
    'dl',
    { class: 'kv' },
    rows.filter(Boolean).map(([k, v]) => [h('dt', {}, k), h('dd', {}, v)]),
  );
}

export function Tabs({ tabs, active, onChange, label = 'Tabs' }) {
  return h(
    'div',
    { class: 'tabs', role: 'tablist', 'aria-label': label },
    tabs.map((t) =>
      h(
        'button',
        {
          class: ['tab', t.id === active && 'is-active'],
          role: 'tab',
          'aria-selected': String(t.id === active),
          onClick: () => onChange(t.id),
        },
        t.label,
        t.count !== undefined ? h('span', { class: 'tab-count' }, String(t.count)) : null,
      ),
    ),
  );
}

export function Table({ columns, rows, empty = 'Nothing here yet.', onRowClick, className }) {
  if (!rows.length) return EmptyState({ text: empty });
  return h(
    'div',
    { class: ['table-wrap', className] },
    h(
      'table',
      { class: 'table' },
      h('thead', {}, h('tr', {}, columns.map((c) => h('th', { class: c.align && `al-${c.align}` }, c.label)))),
      h(
        'tbody',
        {},
        rows.map((row) =>
          h(
            'tr',
            { class: onRowClick && 'is-clickable', onClick: onRowClick ? () => onRowClick(row) : undefined },
            columns.map((c) => h('td', { class: c.align && `al-${c.align}` }, c.render ? c.render(row) : row[c.key])),
          ),
        ),
      ),
    ),
  );
}

export function EmptyState({ icon: iconName = 'info', title, text }) {
  return h(
    'div',
    { class: 'empty' },
    h('span', { class: 'empty-icon' }, icon(iconName, { size: 22 })),
    title ? h('div', { class: 'empty-title' }, title) : null,
    text ? h('p', { class: 'empty-text' }, text) : null,
  );
}

export function Field({ label, hint, control, id }) {
  return h('label', { class: 'field', for: id }, h('span', { class: 'field-label' }, label), control, hint ? h('span', { class: 'field-hint' }, hint) : null);
}

export function TextInput({ value = '', placeholder, onCommit, maxLength = 40, id, ariaLabel }) {
  const input = h('input', { class: 'input', type: 'text', value, placeholder, maxlength: maxLength, id, 'aria-label': ariaLabel });
  if (onCommit) {
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') input.blur();
      if (e.key === 'Escape') {
        input.value = value;
        input.blur();
      }
    });
    input.addEventListener('change', () => onCommit(input.value, input));
  }
  return input;
}

export function Select({ value, options, onChange, id }) {
  return h(
    'select',
    { class: 'input select', id, onChange: (e) => onChange(e.target.value) },
    options.map((o) => h('option', { value: o.value, selected: String(o.value) === String(value) }, o.label)),
  );
}

export function Toggle({ checked, onChange, label, tip }) {
  return h(
    'label',
    { class: 'toggle', 'data-tip': tip },
    h('input', { type: 'checkbox', checked, onChange: (e) => onChange(e.target.checked) }),
    h('span', { class: 'toggle-track' }, h('span', { class: 'toggle-thumb' })),
    label ? h('span', { class: 'toggle-label' }, label) : null,
  );
}

export function Progress(value, target) {
  const pct = target ? Math.min(100, (value / target) * 100) : 0;
  return h(
    'div',
    { class: 'progress', role: 'progressbar', 'aria-valuemin': '0', 'aria-valuemax': String(target), 'aria-valuenow': String(value) },
    h('span', { class: 'progress-bar', style: { width: `${pct}%` } }),
  );
}

export function SectionTitle(text, extra) {
  return h('div', { class: 'section-title' }, h('span', {}, text), extra || null);
}
