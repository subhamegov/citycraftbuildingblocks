// Notifications, modals, drawers and tooltips.

import { h, clear } from './dom.js';
import { icon } from './icons.js';
import { Button } from './components.js';

// Toasts

const TOAST_ICONS = { info: 'info', success: 'check', warning: 'info', error: 'close' };

export function notify(message, tone = 'info', { timeout = 3200, title } = {}) {
  const root = document.getElementById('toasts');
  if (!root) return;
  const el = h(
    'div',
    { class: ['toast', `toast-${tone}`], role: tone === 'error' || tone === 'warning' ? 'alert' : 'status' },
    h('span', { class: 'toast-icon' }, icon(TOAST_ICONS[tone] || 'info', { size: 16 })),
    h('div', { class: 'toast-body' }, title ? h('strong', {}, title) : null, h('span', {}, message)),
  );
  root.appendChild(el);
  while (root.children.length > 4) root.firstChild.remove();
  requestAnimationFrame(() => el.classList.add('is-in'));
  setTimeout(() => {
    el.classList.remove('is-in');
    setTimeout(() => el.remove(), 250);
  }, timeout);
}

// Modals

let openModalState = null;

export function openModal({ title, body, actions = [], dismissible = true, size = 'md' }) {
  closeModal();
  const root = document.getElementById('modal-root');
  const previouslyFocused = document.activeElement;
  const close = () => closeModal();
  const dialog = h(
    'div',
    { class: ['modal', `modal-${size}`], role: 'dialog', 'aria-modal': 'true', 'aria-label': title },
    h(
      'header',
      { class: 'modal-header' },
      h('h2', {}, title),
      dismissible ? Button({ icon: 'close', variant: 'ghost', size: 'sm', tip: 'Close', onClick: close }) : null,
    ),
    h('div', { class: 'modal-body' }, body),
    actions.length ? h('footer', { class: 'modal-footer' }, actions) : null,
  );
  const backdrop = h('div', { class: 'modal-backdrop', onClick: (e) => dismissible && e.target === backdrop && close() }, dialog);
  root.appendChild(backdrop);
  requestAnimationFrame(() => {
    backdrop.classList.add('is-in');
    (dialog.querySelector('input, select, .btn-primary') || dialog).focus?.();
  });
  openModalState = { backdrop, dismissible, previouslyFocused };
  return close;
}

export function closeModal() {
  if (!openModalState) return;
  const { backdrop, previouslyFocused } = openModalState;
  openModalState = null;
  backdrop.remove();
  previouslyFocused?.focus?.();
}

export function isModalOpen() {
  return Boolean(openModalState);
}

export function modalDismissible() {
  return Boolean(openModalState?.dismissible);
}

export function confirmDialog({ title, message, confirmLabel = 'Confirm', tone = 'danger', extra }) {
  return new Promise((resolve) => {
    let done = false;
    const finish = (v) => {
      if (done) return;
      done = true;
      closeModal();
      resolve(v);
    };
    openModal({
      title,
      body: [h('p', {}, message), extra || null],
      actions: [
        Button({ label: 'Cancel', variant: 'secondary', onClick: () => finish(false) }),
        Button({ label: confirmLabel, variant: tone === 'danger' ? 'danger' : 'primary', onClick: () => finish(true) }),
      ],
    });
  });
}

// Drawer (slides in from the right, used for record details)

export function openDrawer({ title, body }) {
  closeDrawer();
  const el = h(
    'aside',
    { class: 'drawer', id: 'drawer', role: 'dialog', 'aria-label': title },
    h('header', { class: 'drawer-header' }, h('h2', {}, title), Button({ icon: 'close', variant: 'ghost', size: 'sm', tip: 'Close', onClick: closeDrawer })),
    h('div', { class: 'drawer-body' }, body),
  );
  document.body.appendChild(el);
  requestAnimationFrame(() => el.classList.add('is-in'));
}

export function closeDrawer() {
  const el = document.getElementById('drawer');
  if (!el) return false;
  el.remove();
  return true;
}

// Tooltips: any element with data-tip gets one.

export function installTooltips() {
  const tip = document.getElementById('tooltip');
  let current = null;
  const hide = () => {
    tip.classList.remove('is-in');
    current = null;
  };
  document.addEventListener('pointerover', (e) => {
    const target = e.target.closest?.('[data-tip]');
    if (!target || target === current) return;
    current = target;
    clear(tip).append(target.dataset.tip);
    const r = target.getBoundingClientRect();
    tip.classList.add('is-in');
    const tw = tip.offsetWidth;
    const th = tip.offsetHeight;
    let left = r.left + r.width / 2 - tw / 2;
    left = Math.max(8, Math.min(left, window.innerWidth - tw - 8));
    let top = r.bottom + 8;
    if (top + th > window.innerHeight - 8) top = r.top - th - 8;
    tip.style.left = `${left}px`;
    tip.style.top = `${top}px`;
  });
  document.addEventListener('pointerout', (e) => {
    if (current && !current.contains(e.relatedTarget)) hide();
  });
  document.addEventListener('pointerdown', hide);
}
