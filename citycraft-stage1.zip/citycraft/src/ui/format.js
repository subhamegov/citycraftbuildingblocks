import { formatGameDate } from '../simulation/calendar.js';

const nf = new Intl.NumberFormat('en-US');

export const fmt = {
  number: (n) => nf.format(Math.round(n)),
  credits: (n, short = 'cr') => `${nf.format(Math.round(n))} ${short}`,
  signedCredits: (n, short = 'cr') => `${n >= 0 ? '+' : '−'}${nf.format(Math.abs(Math.round(n)))} ${short}`,
  percent: (n) => `${Math.round(n)}%`,
  date: (day) => formatGameDate(day),
  bytes: (b) => (b > 1024 * 1024 ? `${(b / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`),
  when: (iso) => {
    if (!iso) return 'Never';
    const d = new Date(iso);
    return Number.isNaN(d.getTime()) ? 'Unknown' : d.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
  },
};
