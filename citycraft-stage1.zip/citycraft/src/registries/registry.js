// Generic shared registry. Every registry (boundaries, properties, addresses,
// people, businesses, assets) has the same shape, so municipal services can
// all reference records by id instead of keeping their own copies.
//
// Writers here are only called from command handlers.

export function createRegistry(kind, idPrefix) {
  return { kind, idPrefix, schemaVersion: 1, nextSeq: 1, order: [], records: {} };
}

export function makeId(registry, seq) {
  return `${registry.idPrefix}-${String(seq).padStart(4, '0')}`;
}

export function registerRecord(registry, data, day) {
  const id = makeId(registry, registry.nextSeq);
  registry.nextSeq += 1;
  const record = { id, version: 1, createdDay: day, updatedDay: day, links: {}, ...data };
  registry.records[id] = record;
  registry.order.push(id);
  return record;
}

export function updateRecord(registry, id, patch, day) {
  const record = registry.records[id];
  if (!record) throw new Error(`No record ${id} in ${registry.kind}`);
  Object.assign(record, patch, { version: record.version + 1, updatedDay: day });
  return record;
}

/** Store a reference from one record to another, e.g. property -> address. */
export function linkRecord(registry, id, relation, targetId) {
  const record = registry.records[id];
  if (!record) throw new Error(`No record ${id} in ${registry.kind}`);
  const list = record.links[relation] || (record.links[relation] = []);
  if (!list.includes(targetId)) list.push(targetId);
}

// Read helpers
export function getRecord(registry, id) {
  return registry?.records[id] ?? null;
}

export function listRecords(registry) {
  return registry ? registry.order.map((id) => registry.records[id]) : [];
}

export function countRecords(registry) {
  return registry ? registry.order.length : 0;
}
