// Shared entity registries. Stage 1 creates every registry and fills the
// boundary registry with the four wards. Other registries start empty and are
// filled by later stages through commands.

import { createRegistry, registerRecord, listRecords } from './registry.js';

export function createRegistries(config, world) {
  const registries = {};
  for (const def of config.registries.registries) {
    registries[def.id] = createRegistry(def.id, def.idPrefix);
  }
  for (const ward of config.wards.wards) {
    const tiles = world.tiles.filter((t) => t.ward === ward.code);
    const xs = tiles.map((t) => t.x);
    const ys = tiles.map((t) => t.y);
    registerRecord(
      registries.boundaries,
      {
        type: 'ward',
        code: ward.code,
        name: ward.name,
        description: ward.description,
        bounds: { minX: Math.min(...xs), maxX: Math.max(...xs), minY: Math.min(...ys), maxY: Math.max(...ys) },
        areaTiles: tiles.length,
      },
      0,
    );
  }
  return registries;
}

export function wardRecordByCode(registries, code) {
  return listRecords(registries.boundaries).find((r) => r.code === code) || null;
}

export function wardName(registries, code) {
  return wardRecordByCode(registries, code)?.name ?? code;
}
