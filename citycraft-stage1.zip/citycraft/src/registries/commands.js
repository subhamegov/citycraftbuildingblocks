import { updateRecord } from './registry.js';
import { wardRecordByCode } from './index.js';

export const registryCommands = [
  {
    type: 'registry/renameWard',
    touches: ['registries'],
    validate(state, { code, name }) {
      if (!wardRecordByCode(state.registries, code)) return `Unknown ward ${code}`;
      const clean = String(name ?? '').trim();
      if (clean.length < 2 || clean.length > 28) return 'Ward names need 2 to 28 characters';
      return null;
    },
    apply(state, { code, name }, ctx) {
      const record = wardRecordByCode(state.registries, code);
      const old = record.name;
      updateRecord(state.registries.boundaries, record.id, { name: String(name).trim() }, state.simulation.day);
      ctx.journal(`Ward ${code} renamed from ${old} to ${record.name}.`);
      ctx.emit('registry.updated', { registry: 'boundaries', id: record.id });
    },
  },
];
