// Read helpers for the physical grid. Pure functions, safe to call anywhere.

export function tileIndex(world, x, y) {
  return y * world.width + x;
}

export function inBounds(world, x, y) {
  return Number.isInteger(x) && Number.isInteger(y) && x >= 0 && y >= 0 && x < world.width && y < world.height;
}

export function getTile(world, x, y) {
  return inBounds(world, x, y) ? world.tiles[tileIndex(world, x, y)] : null;
}

export function tileId(x, y) {
  return `T-${String(x).padStart(2, '0')}-${String(y).padStart(2, '0')}`;
}

export function isBuildableTerrain(config, terrain) {
  return Boolean(config.terrain.types[terrain]?.buildable);
}

/** An open plot is buildable land with nothing on it. */
export function isOpenPlot(config, tile) {
  return Boolean(tile) && isBuildableTerrain(config, tile.terrain) && !tile.tree && !tile.structure;
}

export function plotStatus(config, tile) {
  if (!tile) return { key: 'none', label: 'Outside the city' };
  if (tile.terrain === 'water') return { key: 'water', label: 'Water, cannot build' };
  if (!isBuildableTerrain(config, tile.terrain)) return { key: 'unbuildable', label: 'Not buildable' };
  if (tile.structure) return { key: 'developed', label: 'Developed' };
  if (tile.tree) return { key: 'wooded', label: 'Wooded, clear trees first' };
  return { key: 'open', label: 'Open plot, ready to build' };
}

export function wardOfTile(config, x, y) {
  const { split, wards } = config.wards;
  const quadrant = (y < split.y ? 'n' : 's') + (x < split.x ? 'w' : 'e');
  return wards.find((w) => w.quadrant === quadrant).code;
}
