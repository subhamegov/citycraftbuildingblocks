// Commands that change the physical city. Stage 1: landscaping only.

import { getTile, isBuildableTerrain } from './tiles.js';
import { canAfford, postTransaction } from '../simulation/economy.js';
import { costOf } from '../config/configService.js';

export const physicalCommands = [
  {
    type: 'world/clearTree',
    touches: ['world', 'economy'],
    validate(state, { x, y }, ctx) {
      const tile = getTile(state.world, x, y);
      if (!tile) return 'That spot is outside the city';
      if (!tile.tree) return 'There are no trees on this plot';
      const cost = costOf(ctx.config, 'clearTree');
      if (!canAfford(state, cost)) return `Not enough credits. Clearing costs ${cost}.`;
      return null;
    },
    apply(state, { x, y }, ctx) {
      const tile = getTile(state.world, x, y);
      tile.tree = null;
      postTransaction(
        state,
        { amount: -costOf(ctx.config, 'clearTree'), category: 'Landscaping', memo: `Cleared trees at ${x},${y}` },
        ctx,
      );
      ctx.emit('world.tileChanged', { x, y });
    },
  },
  {
    type: 'world/plantTree',
    touches: ['world', 'economy'],
    validate(state, { x, y }, ctx) {
      const tile = getTile(state.world, x, y);
      if (!tile) return 'That spot is outside the city';
      if (!isBuildableTerrain(ctx.config, tile.terrain)) return 'Trees only grow on grass or meadow';
      if (tile.tree) return 'This plot already has trees';
      if (tile.structure) return 'Something is already built here';
      const cost = costOf(ctx.config, 'plantTree');
      if (!canAfford(state, cost)) return `Not enough credits. Planting costs ${cost}.`;
      return null;
    },
    apply(state, { x, y }, ctx) {
      const tile = getTile(state.world, x, y);
      tile.tree = ctx.rng.next() < 0.5 ? 'pine' : 'oak';
      postTransaction(
        state,
        { amount: -costOf(ctx.config, 'plantTree'), category: 'Landscaping', memo: `Planted a tree at ${x},${y}` },
        ctx,
      );
      ctx.emit('world.tileChanged', { x, y });
    },
  },
];
