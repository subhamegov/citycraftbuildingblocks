// Deterministic generation of the starting landscape. Same seed, same map.

import { hash2, valueNoise } from '../core/rng.js';
import { wardOfTile } from './tiles.js';

export function generateWorld(config, seed) {
  const { width, height } = config.game.grid;
  const gen = config.terrain.generation;
  const lakeWard = config.wards.wards.find((w) => (w.features || []).includes('lake'));
  const lake = lakeWard ? lakeCentre(config, lakeWard, seed) : null;
  const centre = { x: config.wards.split.x - 0.5, y: config.wards.split.y - 0.5 };

  const tiles = [];
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const ward = wardOfTile(config, x, y);
      let terrain = 'grass';

      if (lake) {
        const wobble = (valueNoise(x, y, seed ^ 0x51ed, 3) - 0.5) * 1.6;
        const d = Math.hypot(x - lake.x, y - lake.y) + wobble;
        if (d < gen.lakeRadius) terrain = 'water';
        else if (d < gen.lakeRadius + 1.1) terrain = 'sand';
      }
      if (terrain === 'grass' && valueNoise(x, y, seed ^ 0x9e37, 7) > gen.meadowThreshold) terrain = 'meadow';

      let tree = null;
      const nearCentre = Math.hypot(x - centre.x, y - centre.y) < gen.clearRadiusAroundCentre;
      if ((terrain === 'grass' || terrain === 'meadow') && !nearCentre) {
        const forest = valueNoise(x, y, seed ^ 0x7f4a, 6) * 0.75 + valueNoise(x, y, seed ^ 0x1234, 3) * 0.25;
        const scatter = hash2(x, y, seed ^ 0xabc) < gen.scatterTreeChance;
        if (forest > gen.forestThreshold || scatter) {
          tree = hash2(x, y, seed ^ 0x77) < (ward === 'W1' ? 0.7 : 0.4) ? 'pine' : 'oak';
        }
      }

      tiles.push({
        x,
        y,
        ward,
        terrain,
        shade: Math.round(hash2(x, y, seed ^ 0x5eed) * 100) / 100,
        tree,
        structure: null,
      });
    }
  }

  return {
    width,
    height,
    tiles,
    // Reserved for later stages: buildings, roads and networks keyed by id.
    structures: {},
    nextStructureSeq: 1,
  };
}

function lakeCentre(config, ward, seed) {
  const { width, height } = config.game.grid;
  const { split } = config.wards;
  const xs = ward.quadrant.includes('w') ? [0, split.x] : [split.x, width];
  const ys = ward.quadrant.includes('n') ? [0, split.y] : [split.y, height];
  const margin = 5;
  const jx = hash2(1, 2, seed);
  const jy = hash2(3, 4, seed);
  return {
    x: Math.round(xs[0] + margin + jx * (xs[1] - xs[0] - margin * 2)),
    y: Math.round(ys[0] + margin + jy * (ys[1] - ys[0] - margin * 2)),
  };
}
