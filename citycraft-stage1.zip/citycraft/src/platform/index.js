// Reusable platform services: identity, registry access, workflow, payments,
// notifications and documents. Municipal applications are meant to be built
// from these shared parts instead of each one building its own.
//
// Stage 1 defines the state shape and the service contract only. No service
// can be switched on yet, and the UI shows them as information, not controls.

export const SERVICE_STATUS = Object.freeze({
  UNAVAILABLE: 'unavailable',
  AVAILABLE: 'available',
  ACTIVE: 'active',
});

export function createPlatformState(config) {
  const services = {};
  for (const svc of config.platformServices.services) {
    services[svc.id] = { status: SERVICE_STATUS.UNAVAILABLE, activatedDay: null, settings: {} };
  }
  return { services, requestLog: [] };
}

/**
 * Contract every platform service will implement in later stages.
 * @typedef {object} PlatformService
 * @property {string} id
 * @property {(state: object, ctx: object) => void} activate   Called from a command.
 * @property {(state: object, request: object, ctx: object) => object} handle  Pure request handler.
 * @property {(state: object, ctx: object) => void} [onTick]  Optional daily step.
 */
export const platformServiceRegistry = new Map();

export function registerPlatformService(service) {
  if (!service?.id) throw new Error('Platform service needs an id');
  platformServiceRegistry.set(service.id, service);
}

export function serviceStatus(state, id) {
  return state.platform.services[id]?.status ?? SERVICE_STATUS.UNAVAILABLE;
}
