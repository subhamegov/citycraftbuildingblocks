// Ward boundaries, ward name labels and the buildable-plot outline overlay.

import * as THREE from 'three';
import { tileCentre, tileTop } from './coords.js';

const HALF = 0.475;
const STRIP = 0.075;

export class OverlayLayer {
  constructor() {
    this.group = new THREE.Group();
    this.group.name = 'overlays';
    this.borders = null;
    this.plots = null;
    this.labels = new THREE.Group();
    this.labels.name = 'ward-labels';
    this.group.add(this.labels);
    this.borderMat = new THREE.MeshBasicMaterial({
      vertexColors: true,
      transparent: true,
      opacity: 0.9,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -2,
    });
    this.plotMat = new THREE.LineBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0.55, depthWrite: false });
    this.visible = { wards: true, plots: false };
  }

  build(view) {
    this.buildBorders(view);
    this.buildPlots(view);
    this.buildLabels(view);
    this.apply();
  }

  buildBorders(view) {
    if (this.borders) {
      this.group.remove(this.borders);
      this.borders.geometry.dispose();
    }
    const { width, height, tiles } = view;
    const colors = Object.fromEntries(view.wards.map((w) => [w.code, new THREE.Color(w.color)]));
    const pos = [];
    const col = [];
    const quad = (x0, z0, x1, z1, y, c) => {
      pos.push(x0, y, z0, x0, y, z1, x1, y, z1, x0, y, z0, x1, y, z1, x1, y, z0);
      for (let i = 0; i < 6; i++) col.push(c.r, c.g, c.b);
    };
    const wardAt = (x, y) => (x < 0 || y < 0 || x >= width || y >= height ? null : tiles[y * width + x].ward);
    for (const t of tiles) {
      const c = tileCentre(t.x, t.y, width, height);
      const y = tileTop(t) + 0.012;
      const color = colors[t.ward];
      if (wardAt(t.x, t.y - 1) !== t.ward) quad(c.x - HALF, c.z - HALF, c.x + HALF, c.z - HALF + STRIP, y, color);
      if (wardAt(t.x, t.y + 1) !== t.ward) quad(c.x - HALF, c.z + HALF - STRIP, c.x + HALF, c.z + HALF, y, color);
      if (wardAt(t.x - 1, t.y) !== t.ward) quad(c.x - HALF, c.z - HALF, c.x - HALF + STRIP, c.z + HALF, y, color);
      if (wardAt(t.x + 1, t.y) !== t.ward) quad(c.x + HALF - STRIP, c.z - HALF, c.x + HALF, c.z + HALF, y, color);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    this.borders = new THREE.Mesh(geo, this.borderMat);
    this.borders.name = 'ward-borders';
    this.borders.renderOrder = 2;
    this.group.add(this.borders);
  }

  /** Outline every open plot, so the player can see where building is possible. */
  buildPlots(view) {
    if (this.plots) {
      this.group.remove(this.plots);
      this.plots.geometry.dispose();
    }
    const { width, height, tiles } = view;
    const pts = [];
    const h = 0.43;
    for (const t of tiles) {
      if (!view.isOpenPlot(t)) continue;
      const c = tileCentre(t.x, t.y, width, height);
      const y = 0.015;
      const a = [c.x - h, y, c.z - h];
      const b = [c.x + h, y, c.z - h];
      const d = [c.x + h, y, c.z + h];
      const e = [c.x - h, y, c.z + h];
      pts.push(...a, ...b, ...b, ...d, ...d, ...e, ...e, ...a);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3));
    this.plots = new THREE.LineSegments(geo, this.plotMat);
    this.plots.name = 'plot-outlines';
    this.group.add(this.plots);
  }

  buildLabels(view) {
    for (const s of [...this.labels.children]) {
      this.labels.remove(s);
      s.material.map.dispose();
      s.material.dispose();
    }
    for (const w of view.wards) {
      const c = tileCentre(w.center.x, w.center.y, view.width, view.height);
      const sprite = makeLabel(w.name, w.code, w.color);
      sprite.position.set(c.x + 0.5, 2.6, c.z + 0.5);
      sprite.userData.code = w.code;
      this.labels.add(sprite);
    }
  }

  setVisibility({ wards, plots }) {
    if (wards !== undefined) this.visible.wards = wards;
    if (plots !== undefined) this.visible.plots = plots;
    this.apply();
  }

  apply() {
    if (this.borders) this.borders.visible = this.visible.wards;
    this.labels.visible = this.visible.wards;
    if (this.plots) this.plots.visible = this.visible.plots;
  }

  dispose() {
    this.borders?.geometry.dispose();
    this.plots?.geometry.dispose();
    this.borderMat.dispose();
    this.plotMat.dispose();
    for (const s of this.labels.children) {
      s.material.map.dispose();
      s.material.dispose();
    }
  }
}

function makeLabel(name, code, color) {
  const scale = 2;
  const font = `600 ${15 * scale}px system-ui, -apple-system, "Segoe UI", sans-serif`;
  const small = `600 ${11 * scale}px system-ui, -apple-system, "Segoe UI", sans-serif`;
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  ctx.font = font;
  const textW = ctx.measureText(name).width;
  ctx.font = small;
  const codeW = ctx.measureText(code).width;
  const padX = 14 * scale;
  const w = Math.ceil(padX * 2 + 14 * scale + textW + 10 * scale + codeW);
  const h = 34 * scale;
  canvas.width = w;
  canvas.height = h + 8 * scale;
  ctx.font = font;
  // Shadow + pill
  ctx.fillStyle = 'rgba(15, 30, 50, 0.18)';
  roundRect(ctx, 2 * scale, 4 * scale, w - 4 * scale, h, h / 2);
  ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.96)';
  roundRect(ctx, 2 * scale, 1 * scale, w - 4 * scale, h - 2 * scale, h / 2);
  ctx.fill();
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(padX + 5 * scale, h / 2, 5 * scale, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#1d2733';
  ctx.textBaseline = 'middle';
  ctx.fillText(name, padX + 16 * scale, h / 2 + 1);
  ctx.font = small;
  ctx.fillStyle = '#6b7785';
  ctx.fillText(code, padX + 16 * scale + textW + 8 * scale, h / 2 + 1);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  const mat = new THREE.SpriteMaterial({ map: tex, depthTest: false, transparent: true });
  const sprite = new THREE.Sprite(mat);
  const worldH = 0.95;
  sprite.scale.set((worldH * canvas.width) / canvas.height, worldH, 1);
  sprite.renderOrder = 10;
  return sprite;
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}
