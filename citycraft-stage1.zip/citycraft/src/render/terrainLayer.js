// The plot grid: one instanced mesh for land and one for water.

import * as THREE from 'three';
import { tileCentre, tileTop, WATER_TOP, BASE_TOP } from './coords.js';

const PLOT = 0.95;

export class TerrainLayer {
  constructor() {
    this.group = new THREE.Group();
    this.group.name = 'terrain';
    this.land = null;
    this.water = null;
    this.lookup = []; // tile index -> { mesh, i }
    this.landGeo = new THREE.BoxGeometry(PLOT, -BASE_TOP, PLOT);
    this.landGeo.translate(0, BASE_TOP / 2, 0);
    this.waterGeo = new THREE.BoxGeometry(1, WATER_TOP - BASE_TOP, 1);
    this.waterGeo.translate(0, (WATER_TOP + BASE_TOP) / 2, 0);
    this.landMat = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.95, metalness: 0 });
    this.waterMat = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.2, metalness: 0.1, transparent: true, opacity: 0.9 });
    this._tmpColor = new THREE.Color();
    this._wardColor = new THREE.Color();
  }

  build(view) {
    this._disposeMeshes();
    const { width, height, tiles } = view;
    const waterCount = tiles.filter((t) => t.terrain === 'water').length;
    const landCount = tiles.length - waterCount;
    this.land = new THREE.InstancedMesh(this.landGeo, this.landMat, Math.max(landCount, 1));
    this.water = new THREE.InstancedMesh(this.waterGeo, this.waterMat, Math.max(waterCount, 1));
    this.land.count = landCount;
    this.water.count = waterCount;
    this.land.receiveShadow = true;
    this.water.receiveShadow = true;
    this.land.name = 'land-plots';
    this.water.name = 'water';

    const m = new THREE.Matrix4();
    let li = 0;
    let wi = 0;
    this.lookup = new Array(tiles.length);
    tiles.forEach((t, idx) => {
      const c = tileCentre(t.x, t.y, width, height);
      const y = t.terrain === 'sand' ? tileTop(t) : 0;
      m.makeTranslation(c.x, y, c.z);
      if (t.terrain === 'water') {
        this.water.setMatrixAt(wi, m);
        this.lookup[idx] = { mesh: this.water, i: wi++ };
      } else {
        this.land.setMatrixAt(li, m);
        this.lookup[idx] = { mesh: this.land, i: li++ };
      }
    });
    this.land.instanceMatrix.needsUpdate = true;
    this.water.instanceMatrix.needsUpdate = true;
    this.land.computeBoundingSphere();
    this.water.computeBoundingSphere();
    this.group.add(this.land, this.water);
  }

  /** Colour every plot from its terrain, variation and ward overlay. */
  recolor(view, { wardTint = false, selectedWard = null } = {}) {
    if (!this.land) return;
    const wardColors = Object.fromEntries(view.wards.map((w) => [w.code, w.color]));
    view.tiles.forEach((t, idx) => {
      const c = this._tmpColor.set(view.terrainColors[t.terrain] || '#888888');
      c.offsetHSL(0, 0, (t.shade - 0.5) * 0.06);
      if (t.tree) c.offsetHSL(0.01, -0.05, -0.06);
      if (wardTint || selectedWard) {
        let amount = wardTint ? 0.12 : 0;
        if (selectedWard) amount = t.ward === selectedWard ? 0.38 : wardTint ? 0.05 : 0;
        if (t.terrain === 'water') amount *= 0.4;
        c.lerp(this._wardColor.set(wardColors[t.ward]), amount);
      }
      const { mesh, i } = this.lookup[idx];
      mesh.setColorAt(i, c);
    });
    if (this.land.instanceColor) this.land.instanceColor.needsUpdate = true;
    if (this.water.instanceColor) this.water.instanceColor.needsUpdate = true;
  }

  instanceCounts() {
    return { land: this.land?.count ?? 0, water: this.water?.count ?? 0 };
  }

  _disposeMeshes() {
    for (const mesh of [this.land, this.water]) {
      if (!mesh) continue;
      this.group.remove(mesh);
      mesh.dispose();
    }
    this.land = null;
    this.water = null;
  }

  dispose() {
    this._disposeMeshes();
    this.landGeo.dispose();
    this.waterGeo.dispose();
    this.landMat.dispose();
    this.waterMat.dispose();
  }
}
