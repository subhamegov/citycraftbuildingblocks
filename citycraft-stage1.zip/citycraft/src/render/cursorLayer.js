// Hover and selection indicators.

import * as THREE from 'three';
import { tileCentre, tileTop } from './coords.js';

function frameGeometry(outer, inner) {
  const shape = new THREE.Shape();
  shape.moveTo(-outer, -outer);
  shape.lineTo(outer, -outer);
  shape.lineTo(outer, outer);
  shape.lineTo(-outer, outer);
  shape.closePath();
  const hole = new THREE.Path();
  hole.moveTo(-inner, -inner);
  hole.lineTo(-inner, inner);
  hole.lineTo(inner, inner);
  hole.lineTo(inner, -inner);
  hole.closePath();
  shape.holes.push(hole);
  const geo = new THREE.ShapeGeometry(shape);
  geo.rotateX(-Math.PI / 2);
  return geo;
}

export const TOOL_COLORS = {
  select: '#ffffff',
  clearTree: '#f2b441',
  plantTree: '#7be08a',
  invalid: '#ef6b5b',
};

export class CursorLayer {
  constructor() {
    this.group = new THREE.Group();
    this.group.name = 'cursor';
    const frame = frameGeometry(0.5, 0.42);
    const fill = new THREE.PlaneGeometry(0.84, 0.84).rotateX(-Math.PI / 2);

    this.hoverMat = new THREE.MeshBasicMaterial({ color: TOOL_COLORS.select, transparent: true, opacity: 0.95, depthWrite: false });
    this.hoverFillMat = new THREE.MeshBasicMaterial({ color: TOOL_COLORS.select, transparent: true, opacity: 0.16, depthWrite: false });
    this.hover = new THREE.Group();
    this.hover.add(new THREE.Mesh(frame, this.hoverMat), new THREE.Mesh(fill, this.hoverFillMat));
    this.hover.visible = false;
    this.hover.renderOrder = 5;

    this.selMat = new THREE.MeshBasicMaterial({ color: '#2f6fe0', transparent: true, opacity: 1, depthWrite: false });
    this.selFrame = new THREE.Mesh(frameGeometry(0.52, 0.4), this.selMat);
    this.marker = new THREE.Mesh(
      new THREE.ConeGeometry(0.16, 0.38, 4).rotateX(Math.PI),
      new THREE.MeshStandardMaterial({ color: '#2f6fe0', roughness: 0.4, flatShading: true }),
    );
    this.marker.castShadow = false;
    this.selection = new THREE.Group();
    this.selection.add(this.selFrame, this.marker);
    this.selection.visible = false;

    this.group.add(this.hover, this.selection);
    this.geos = [frame, fill, this.selFrame.geometry, this.marker.geometry];
    this.t = 0;
  }

  setHover(tile, view, color = TOOL_COLORS.select) {
    if (!tile) {
      this.hover.visible = false;
      return;
    }
    const c = tileCentre(tile.x, tile.y, view.width, view.height);
    this.hover.position.set(c.x, tileTop(tile) + 0.02, c.z);
    this.hoverMat.color.set(color);
    this.hoverFillMat.color.set(color);
    this.hover.visible = true;
  }

  setSelection(tile, view) {
    if (!tile) {
      this.selection.visible = false;
      return;
    }
    const c = tileCentre(tile.x, tile.y, view.width, view.height);
    this.baseY = tileTop(tile) + 0.025;
    this.selection.position.set(c.x, this.baseY, c.z);
    this.selection.visible = true;
  }

  update(dt) {
    this.t += dt;
    if (!this.selection.visible) return;
    const pulse = 1 + Math.sin(this.t * 4) * 0.035;
    this.selFrame.scale.set(pulse, 1, pulse);
    this.marker.position.y = 1.05 + Math.sin(this.t * 2.4) * 0.12;
    this.marker.rotation.y += dt * 1.2;
  }

  dispose() {
    this.geos.forEach((g) => g.dispose());
    [this.hoverMat, this.hoverFillMat, this.selMat, this.marker.material].forEach((m) => m.dispose());
  }
}
