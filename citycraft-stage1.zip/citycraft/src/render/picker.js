// Raycast from the mouse into the city to find the tile under the cursor.
// Intersects a ground plane at land height, which is fast and precise for a
// flat grid, then converts the hit point to grid coordinates.

import * as THREE from 'three';
import { worldToTile } from './coords.js';

export class Picker {
  constructor(camera, dom) {
    this.camera = camera;
    this.dom = dom;
    this.raycaster = new THREE.Raycaster();
    this.ndc = new THREE.Vector2();
    this.plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
    this.hit = new THREE.Vector3();
  }

  pick(clientX, clientY, width, height) {
    const rect = this.dom.getBoundingClientRect();
    if (!rect.width || !rect.height) return null;
    this.ndc.set(((clientX - rect.left) / rect.width) * 2 - 1, -((clientY - rect.top) / rect.height) * 2 + 1);
    this.raycaster.setFromCamera(this.ndc, this.camera);
    if (!this.raycaster.ray.intersectPlane(this.plane, this.hit)) return null;
    const t = worldToTile(this.hit.x, this.hit.z, width, height);
    if (t.x < 0 || t.y < 0 || t.x >= width || t.y >= height) return null;
    return t;
  }
}
