// Grid <-> world conversion. Tile (0,0) is the north-west corner. +x is east,
// +z is south. One tile is one world unit. Land tiles have their top at y = 0.

export const LAND_TOP = 0;
export const WATER_TOP = -0.14;
export const SHORE_TOP = -0.03;
export const BASE_TOP = -0.3;

export function tileCentre(x, y, width, height) {
  return { x: x - width / 2 + 0.5, z: y - height / 2 + 0.5 };
}

export function worldToTile(px, pz, width, height) {
  return { x: Math.floor(px + width / 2), y: Math.floor(pz + height / 2) };
}

export function tileTop(tile) {
  if (tile.terrain === 'water') return WATER_TOP;
  if (tile.terrain === 'sand') return SHORE_TOP;
  return LAND_TOP;
}

// Cheap stable hash for visual-only variation (tree offsets, sizes).
export function vhash(a, b, c = 0) {
  let h = Math.imul(a | 0, 73856093) ^ Math.imul(b | 0, 19349663) ^ Math.imul(c | 0, 83492791);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}
