// Trees as instanced low-poly meshes. Rebuilt from state whenever the world
// changes, so trees can never be duplicated by repeated loads.

import * as THREE from 'three';
import { tileCentre, vhash } from './coords.js';

const PINE_GREENS = ['#2f6b3f', '#356f3a', '#2b5f3a', '#3c7a45'];
const OAK_GREENS = ['#5a9a40', '#4f8d3b', '#67a64a', '#78ad4c'];
const AUTUMN = ['#d39a3a', '#c4712f'];

export class VegetationLayer {
  constructor() {
    this.group = new THREE.Group();
    this.group.name = 'vegetation';
    const flat = (color) => new THREE.MeshStandardMaterial({ color, roughness: 0.9, flatShading: true });
    this.geos = {
      trunk: new THREE.CylinderGeometry(0.035, 0.05, 0.28, 5).translate(0, 0.14, 0),
      pineLow: new THREE.ConeGeometry(0.24, 0.42, 7).translate(0, 0.42, 0),
      pineHigh: new THREE.ConeGeometry(0.17, 0.34, 7).translate(0, 0.66, 0),
      crown: new THREE.IcosahedronGeometry(0.24, 0).translate(0, 0.46, 0),
    };
    this.mats = { trunk: flat('#7a5a3c'), foliage: flat('#ffffff') };
    this.meshes = {};
    this.counts = { trees: 0 };
  }

  build(view) {
    this._clear();
    const { width, height, tiles } = view;
    const trees = [];
    for (const t of tiles) {
      if (!t.tree) continue;
      const n = 1 + Math.floor(vhash(t.x, t.y, 1) * 3);
      const c = tileCentre(t.x, t.y, width, height);
      for (let k = 0; k < n; k++) {
        const ang = vhash(t.x, t.y, 10 + k) * Math.PI * 2;
        const r = n === 1 ? vhash(t.x, t.y, 20) * 0.12 : 0.18 + vhash(t.x, t.y, 30 + k) * 0.1;
        trees.push({
          type: t.tree,
          x: c.x + Math.cos(ang + (k * Math.PI * 2) / n) * r,
          z: c.z + Math.sin(ang + (k * Math.PI * 2) / n) * r,
          s: 0.8 + vhash(t.x, t.y, 40 + k) * 0.45,
          rot: vhash(t.x, t.y, 50 + k) * Math.PI * 2,
          tone: vhash(t.x, t.y, 60 + k),
        });
      }
    }
    const pines = trees.filter((t) => t.type === 'pine');
    const oaks = trees.filter((t) => t.type !== 'pine');
    const make = (geo, mat, n, name) => {
      const mesh = new THREE.InstancedMesh(geo, mat, Math.max(n, 1));
      mesh.count = n;
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      mesh.name = name;
      this.group.add(mesh);
      return mesh;
    };
    this.meshes.trunk = make(this.geos.trunk, this.mats.trunk, trees.length, 'tree-trunks');
    this.meshes.pineLow = make(this.geos.pineLow, this.mats.foliage, pines.length, 'pine-low');
    this.meshes.pineHigh = make(this.geos.pineHigh, this.mats.foliage, pines.length, 'pine-high');
    this.meshes.crown = make(this.geos.crown, this.mats.foliage, oaks.length, 'broadleaf');

    const m = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const up = new THREE.Vector3(0, 1, 0);
    const pos = new THREE.Vector3();
    const scl = new THREE.Vector3();
    const col = new THREE.Color();
    const place = (tree) => {
      q.setFromAxisAngle(up, tree.rot);
      pos.set(tree.x, 0, tree.z);
      scl.setScalar(tree.s);
      return m.compose(pos, q, scl);
    };
    trees.forEach((t, i) => this.meshes.trunk.setMatrixAt(i, place(t)));
    pines.forEach((t, i) => {
      place(t);
      this.meshes.pineLow.setMatrixAt(i, m);
      this.meshes.pineHigh.setMatrixAt(i, m);
      col.set(PINE_GREENS[Math.floor(t.tone * PINE_GREENS.length)]);
      this.meshes.pineLow.setColorAt(i, col);
      this.meshes.pineHigh.setColorAt(i, col.offsetHSL(0, 0, 0.04));
    });
    oaks.forEach((t, i) => {
      place(t);
      scl.set(t.s, t.s * (0.9 + t.tone * 0.3), t.s);
      m.compose(pos, q, scl);
      this.meshes.crown.setMatrixAt(i, m);
      const palette = t.tone > 0.93 ? AUTUMN : OAK_GREENS;
      col.set(palette[Math.floor((t.tone * 97) % palette.length)]);
      this.meshes.crown.setColorAt(i, col);
    });
    for (const mesh of Object.values(this.meshes)) {
      mesh.instanceMatrix.needsUpdate = true;
      if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
      mesh.computeBoundingSphere();
    }
    this.counts = { trees: trees.length, pines: pines.length, broadleaf: oaks.length };
  }

  _clear() {
    for (const mesh of Object.values(this.meshes)) {
      this.group.remove(mesh);
      mesh.dispose();
    }
    this.meshes = {};
  }

  dispose() {
    this._clear();
    Object.values(this.geos).forEach((g) => g.dispose());
    Object.values(this.mats).forEach((m) => m.dispose());
  }
}
