// Sky, light, sea, the island the city sits on, and drifting clouds.

import * as THREE from 'three';
import { BASE_TOP } from './coords.js';

export function createEnvironment(scene, { width, height }) {
  const group = new THREE.Group();
  group.name = 'environment';

  // Sky dome with a soft vertical gradient.
  const skyGeo = new THREE.SphereGeometry(450, 32, 16);
  const skyMat = new THREE.ShaderMaterial({
    side: THREE.BackSide,
    depthWrite: false,
    uniforms: {
      top: { value: new THREE.Color('#7fb2e5') },
      horizon: { value: new THREE.Color('#e4eef6') },
      exponent: { value: 0.75 },
    },
    vertexShader: `varying vec3 vPos; void main(){ vPos = (modelMatrix * vec4(position,1.0)).xyz; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
    fragmentShader: `uniform vec3 top; uniform vec3 horizon; uniform float exponent; varying vec3 vPos;
      void main(){ float h = normalize(vPos).y; float t = pow(max(h, 0.0), exponent); gl_FragColor = vec4(mix(horizon, top, t), 1.0); }`,
  });
  const sky = new THREE.Mesh(skyGeo, skyMat);
  sky.renderOrder = -10;
  group.add(sky);

  scene.fog = new THREE.Fog('#dfe9f1', 110, 320);

  const hemi = new THREE.HemisphereLight('#e3f0ff', '#7d7258', 1.15);
  group.add(hemi);

  const sun = new THREE.DirectionalLight('#fff3df', 2.4);
  sun.position.set(26, 42, 18);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  const ext = Math.max(width, height) * 0.8;
  Object.assign(sun.shadow.camera, { left: -ext, right: ext, top: ext, bottom: -ext, near: 1, far: 140 });
  sun.shadow.camera.updateProjectionMatrix();
  sun.shadow.bias = -0.0004;
  sun.shadow.normalBias = 0.03;
  group.add(sun);
  group.add(sun.target);

  // Sea around the island.
  const sea = new THREE.Mesh(
    new THREE.CircleGeometry(420, 72),
    new THREE.MeshStandardMaterial({ color: '#9fcfdc', roughness: 0.55, metalness: 0.05 }),
  );
  sea.rotation.x = -Math.PI / 2;
  sea.position.y = -2.2;
  sea.receiveShadow = true;
  group.add(sea);

  // Island body: grassy top (seen in the gaps between plots), soil, then rock.
  const soil = new THREE.MeshStandardMaterial({ color: '#8a6a48', roughness: 1, flatShading: true });
  const gapTop = new THREE.MeshStandardMaterial({ color: '#4f7a3f', roughness: 1 });
  const rock = new THREE.MeshStandardMaterial({ color: '#8e897d', roughness: 1, flatShading: true });
  const body = new THREE.Mesh(new THREE.BoxGeometry(width + 0.5, 1.1, height + 0.5), [soil, soil, gapTop, soil, soil, soil]);
  body.position.y = BASE_TOP - 0.55;
  body.receiveShadow = true;
  group.add(body);
  const base = new THREE.Mesh(new THREE.BoxGeometry(width + 0.1, 1.2, height + 0.1), rock);
  base.position.y = BASE_TOP - 1.1 - 0.6;
  group.add(base);

  // A few slow clouds for life.
  const clouds = new THREE.Group();
  const cloudMat = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 1, flatShading: true, transparent: true, opacity: 0.92 });
  const blob = new THREE.IcosahedronGeometry(1, 0);
  for (let i = 0; i < 7; i++) {
    const c = new THREE.Group();
    const parts = 3 + (i % 3);
    for (let j = 0; j < parts; j++) {
      const m = new THREE.Mesh(blob, cloudMat);
      const s = 1.2 + ((i * 7 + j * 3) % 5) * 0.25;
      m.scale.set(s * 1.4, s * 0.8, s);
      m.position.set(j * 1.5 - parts * 0.7, ((j * 13) % 3) * 0.25, ((j * 5) % 3) * 0.5);
      c.add(m);
    }
    c.position.set(-70 + i * 22, 15 + (i % 3) * 2.5, -30 + ((i * 37) % 60));
    c.userData.speed = 0.6 + (i % 4) * 0.15;
    clouds.add(c);
  }
  group.add(clouds);

  scene.add(group);

  return {
    group,
    sun,
    update(dtSeconds) {
      for (const c of clouds.children) {
        c.position.x += c.userData.speed * dtSeconds;
        if (c.position.x > 80) c.position.x = -80;
      }
    },
    dispose() {
      group.traverse((o) => {
        o.geometry?.dispose?.();
        const mats = Array.isArray(o.material) ? o.material : o.material ? [o.material] : [];
        mats.forEach((m) => m.dispose());
      });
      scene.remove(group);
      scene.fog = null;
    },
  };
}
