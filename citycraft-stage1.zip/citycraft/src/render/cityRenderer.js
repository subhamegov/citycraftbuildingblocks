// CityRenderer draws a "world view" (plain data built from game state) and
// emits player intent (hover, click, camera moves). It never reads registries
// or services and never changes game state. The app bridge translates its
// events into commands.

import * as THREE from 'three';
import { EventBus } from '../core/eventBus.js';
import { createEnvironment } from './environment.js';
import { TerrainLayer } from './terrainLayer.js';
import { VegetationLayer } from './vegetationLayer.js';
import { OverlayLayer } from './overlayLayer.js';
import { CursorLayer, TOOL_COLORS } from './cursorLayer.js';
import { CameraController } from './cameraController.js';
import { Picker } from './picker.js';
import { tileCentre } from './coords.js';

export function webglAvailable() {
  try {
    const c = document.createElement('canvas');
    return Boolean(window.WebGLRenderingContext && (c.getContext('webgl2') || c.getContext('webgl')));
  } catch {
    return false;
  }
}

export class CityRenderer {
  constructor(container) {
    this.container = container;
    this.events = new EventBus();
    this.view = null;
    this.active = true;
    this.overlays = { wards: true, plots: false };
    this.selection = null;
    this.tool = 'select';
    this.hoverTile = null;
    this.toolValidator = null;

    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.shadowMap.autoUpdate = false; // the city is static between changes
    this.renderer.domElement.className = 'city-canvas';
    this.renderer.domElement.setAttribute('aria-label', 'City view. Click a plot to inspect it.');
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(30, 1, 0.5, 1000);

    this.terrain = new TerrainLayer();
    this.vegetation = new VegetationLayer();
    this.overlay = new OverlayLayer();
    this.cursor = new CursorLayer();
    this.scene.add(this.terrain.group, this.vegetation.group, this.overlay.group, this.cursor.group);

    this.controller = new CameraController(this.camera, this.renderer.domElement);
    this.picker = new Picker(this.camera, this.renderer.domElement);

    this.controller.on('click', ({ clientX, clientY }) => this._handleClick(clientX, clientY));
    this.controller.on('dragstart', () => this._setHover(null));
    this.controller.on('settled', (e) => this.events.emit('cameraSettled', e));

    this._onPointerMove = (e) => {
      if (!this.view || this.controller.isDragging) return;
      this._setHover(this.picker.pick(e.clientX, e.clientY, this.view.width, this.view.height));
    };
    this._onPointerLeave = () => this._setHover(null);
    this.renderer.domElement.addEventListener('pointermove', this._onPointerMove);
    this.renderer.domElement.addEventListener('pointerleave', this._onPointerLeave);

    this._resizeObserver = new ResizeObserver(() => this.resize());
    this._resizeObserver.observe(container);
    this.resize();
  }

  on(type, fn) {
    return this.events.on(type, fn);
  }

  /** Full rebuild from a world view. Used on start, load, reset and import. */
  setWorld(view) {
    const sizeChanged = !this.view || this.view.width !== view.width || this.view.height !== view.height;
    this.view = view;
    if (sizeChanged) {
      this.environment?.dispose();
      this.environment = createEnvironment(this.scene, view);
      this.controller.bounds = Math.max(view.width, view.height) / 2 + 2;
    }
    this.terrain.build(view);
    this.vegetation.build(view);
    this.overlay.build(view);
    this._recolor();
    this._refreshSelection();
    this.hoverTile = null;
    this.cursor.setHover(null);
    this.renderer.shadowMap.needsUpdate = true;
  }

  /** Something on the ground changed (trees now, buildings later). */
  updateWorld(view) {
    this.view = view;
    this.vegetation.build(view);
    this.overlay.buildPlots(view);
    this.overlay.apply();
    this._recolor();
    this._refreshSelection();
    this.renderer.shadowMap.needsUpdate = true;
  }

  updateLabels(view) {
    this.view = view;
    this.overlay.buildLabels(view);
    this.overlay.apply();
  }

  setOverlays(overlays) {
    const changed = overlays.wards !== this.overlays.wards || overlays.plots !== this.overlays.plots;
    if (!changed) return;
    this.overlays = { ...overlays };
    this.overlay.setVisibility(this.overlays);
    this._recolor();
  }

  setSelection(selection) {
    const key = (s) => (s ? JSON.stringify(s) : 'none');
    if (key(selection) === key(this.selection)) return;
    const prevWard = this.selection?.kind === 'ward' ? this.selection.code : null;
    this.selection = selection ? { ...selection } : null;
    const nextWard = this.selection?.kind === 'ward' ? this.selection.code : null;
    if (prevWard !== nextWard) this._recolor();
    this._refreshSelection();
  }

  setTool(tool, validator = null) {
    this.tool = tool;
    this.toolValidator = validator;
    this.renderer.domElement.dataset.tool = tool;
    this._setHover(this.hoverTile, true);
  }

  setCamera(pose, immediate = true) {
    this.controller.setState(pose, { immediate });
  }

  getCamera() {
    return this.controller.getState();
  }

  focusTile(x, y, distance) {
    if (!this.view) return;
    const c = tileCentre(x, y, this.view.width, this.view.height);
    this.controller.focus(c.x, c.z, { distance });
  }

  focusWard(code) {
    const w = this.view?.wards.find((ward) => ward.code === code);
    if (w) this.focusTile(w.center.x + 0.5, w.center.y + 0.5, 34);
  }

  setActive(active) {
    this.active = active;
    this.controller.enabled = active;
    if (!active) this._setHover(null);
  }

  resize() {
    const w = this.container.clientWidth || 1;
    const h = this.container.clientHeight || 1;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  frame(dtMs) {
    if (!this.active) return;
    const dt = Math.min(dtMs, 100) / 1000;
    this.controller.update(dt);
    this.environment?.update(dt);
    this.cursor.update(dt);
    this.renderer.render(this.scene, this.camera);
  }

  /** Counts used by the diagnostics panel and tests to prove nothing is duplicated. */
  stats() {
    let objects = 0;
    this.scene.traverse(() => objects++);
    const info = this.renderer.info;
    return {
      ...this.terrain.instanceCounts(),
      ...this.vegetation.counts,
      wardLabels: this.overlay.labels.children.length,
      sceneObjects: objects,
      drawCalls: info.render.calls,
      triangles: info.render.triangles,
      geometries: info.memory.geometries,
    };
  }

  dispose() {
    this._resizeObserver.disconnect();
    this.renderer.domElement.removeEventListener('pointermove', this._onPointerMove);
    this.renderer.domElement.removeEventListener('pointerleave', this._onPointerLeave);
    this.controller.dispose();
    this.terrain.dispose();
    this.vegetation.dispose();
    this.overlay.dispose();
    this.cursor.dispose();
    this.environment?.dispose();
    this.renderer.dispose();
    this.renderer.domElement.remove();
    this.events.clear();
  }

  // internals

  _tileAt(x, y) {
    return this.view ? this.view.tiles[y * this.view.width + x] : null;
  }

  _recolor() {
    if (!this.view) return;
    const selectedWard = this.selection?.kind === 'ward' ? this.selection.code : null;
    this.terrain.recolor(this.view, { wardTint: this.overlays.wards, selectedWard });
  }

  _refreshSelection() {
    const s = this.selection;
    const tile = s?.kind === 'tile' ? this._tileAt(s.x, s.y) : null;
    this.cursor.setSelection(tile, this.view);
  }

  _setHover(pos, force = false) {
    const same = pos && this.hoverTile && pos.x === this.hoverTile.x && pos.y === this.hoverTile.y;
    if (same && !force) return;
    this.hoverTile = pos ? { x: pos.x, y: pos.y } : null;
    const tile = pos ? this._tileAt(pos.x, pos.y) : null;
    let color = TOOL_COLORS[this.tool] || TOOL_COLORS.select;
    if (tile && this.toolValidator && this.toolValidator(tile) === false) color = TOOL_COLORS.invalid;
    this.cursor.setHover(tile, this.view, color);
    this.events.emit('hover', this.hoverTile);
  }

  _handleClick(clientX, clientY) {
    if (!this.view || !this.active) return;
    const pos = this.picker.pick(clientX, clientY, this.view.width, this.view.height);
    this.events.emit('tileClick', pos);
  }
}
