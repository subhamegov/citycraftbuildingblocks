// 2D overview of the whole city, drawn from the same world view as the 3D
// scene. Click to move the camera.

export class Minimap {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.base = document.createElement('canvas');
    this.view = null;
    this.camera = null;
    this.selection = null;
    this.handlers = new Set();
    this._dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.addEventListener('pointerdown', (e) => this._navigate(e));
    canvas.addEventListener('pointermove', (e) => {
      if (e.buttons === 1) this._navigate(e);
    });
  }

  onNavigate(fn) {
    this.handlers.add(fn);
    return () => this.handlers.delete(fn);
  }

  setWorld(view, { wardTint = true } = {}) {
    this.view = view;
    const size = this.canvas.clientWidth || 168;
    const px = Math.round(size * this._dpr);
    this.canvas.width = px;
    this.canvas.height = px;
    this.base.width = px;
    this.base.height = px;
    const ctx = this.base.getContext('2d');
    const cell = px / view.width;
    const wardColor = Object.fromEntries(view.wards.map((w) => [w.code, w.color]));
    for (const t of view.tiles) {
      ctx.fillStyle = t.tree ? (t.tree === 'pine' ? '#3b7448' : '#5f9a47') : view.terrainColors[t.terrain];
      ctx.fillRect(t.x * cell, t.y * cell, Math.ceil(cell), Math.ceil(cell));
      if (wardTint && t.terrain !== 'water') {
        ctx.globalAlpha = 0.16;
        ctx.fillStyle = wardColor[t.ward];
        ctx.fillRect(t.x * cell, t.y * cell, Math.ceil(cell), Math.ceil(cell));
        ctx.globalAlpha = 1;
      }
    }
    // Ward boundaries
    ctx.lineWidth = Math.max(1, this._dpr);
    ctx.strokeStyle = 'rgba(255,255,255,0.9)';
    ctx.beginPath();
    for (const t of view.tiles) {
      const right = view.tiles[t.y * view.width + t.x + 1];
      const below = view.tiles[(t.y + 1) * view.width + t.x];
      if (t.x < view.width - 1 && right.ward !== t.ward) {
        ctx.moveTo((t.x + 1) * cell, t.y * cell);
        ctx.lineTo((t.x + 1) * cell, (t.y + 1) * cell);
      }
      if (t.y < view.height - 1 && below.ward !== t.ward) {
        ctx.moveTo(t.x * cell, (t.y + 1) * cell);
        ctx.lineTo((t.x + 1) * cell, (t.y + 1) * cell);
      }
    }
    ctx.stroke();
    this.draw();
  }

  setCamera(camera) {
    this.camera = camera;
    this.draw();
  }

  setSelection(selection) {
    this.selection = selection;
    this.draw();
  }

  draw() {
    if (!this.view) return;
    const ctx = this.ctx;
    const px = this.canvas.width;
    const cell = px / this.view.width;
    ctx.clearRect(0, 0, px, px);
    ctx.drawImage(this.base, 0, 0);

    const s = this.selection;
    if (s?.kind === 'tile') {
      ctx.strokeStyle = '#1f5fbf';
      ctx.lineWidth = 2 * this._dpr;
      ctx.strokeRect(s.x * cell - 1, s.y * cell - 1, cell + 2, cell + 2);
    } else if (s?.kind === 'ward') {
      const tiles = this.view.tiles.filter((t) => t.ward === s.code);
      const xs = tiles.map((t) => t.x);
      const ys = tiles.map((t) => t.y);
      ctx.strokeStyle = '#1f5fbf';
      ctx.lineWidth = 2 * this._dpr;
      const minX = Math.min(...xs);
      const minY = Math.min(...ys);
      ctx.strokeRect(minX * cell + 1, minY * cell + 1, (Math.max(...xs) - minX + 1) * cell - 2, (Math.max(...ys) - minY + 1) * cell - 2);
    }

    if (this.camera) {
      const cx = (this.camera.tx + this.view.width / 2) * cell;
      const cy = (this.camera.tz + this.view.height / 2) * cell;
      const r = (this.camera.distance / 2.2) * cell * 0.5;
      // Direction the camera is looking (away from the camera position).
      const dx = -Math.sin(this.camera.azimuth);
      const dy = -Math.cos(this.camera.azimuth);
      ctx.save();
      ctx.translate(cx, cy);
      ctx.fillStyle = 'rgba(31, 95, 191, 0.18)';
      ctx.strokeStyle = 'rgba(31, 95, 191, 0.9)';
      ctx.lineWidth = 1.5 * this._dpr;
      ctx.beginPath();
      ctx.arc(0, 0, r, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(dx * r, dy * r);
      ctx.stroke();
      ctx.fillStyle = '#1f5fbf';
      ctx.beginPath();
      ctx.arc(0, 0, 2.5 * this._dpr, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  _navigate(e) {
    if (!this.view) return;
    const rect = this.canvas.getBoundingClientRect();
    const x = Math.floor(((e.clientX - rect.left) / rect.width) * this.view.width);
    const y = Math.floor(((e.clientY - rect.top) / rect.height) * this.view.height);
    if (x < 0 || y < 0 || x >= this.view.width || y >= this.view.height) return;
    for (const fn of this.handlers) fn({ x, y });
  }
}
