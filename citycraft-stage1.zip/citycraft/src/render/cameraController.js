// Game-style camera: left-drag pans, right-drag (or Shift+drag) rotates and
// tilts, wheel or pinch zooms, WASD/arrows pan, Q/E rotate, +/- zoom.
// Movement is smoothed toward a desired pose every frame.

import * as THREE from 'three';
import { EventBus } from '../core/eventBus.js';

const DRAG_THRESHOLD = 5;
const LIMITS = { minDistance: 12, maxDistance: 78, minPolar: 0.35, maxPolar: 1.2 };

export const DEFAULT_CAMERA = { tx: 0, tz: 1.5, azimuth: Math.PI / 4, polar: 0.92, distance: 50 };

export class CameraController {
  constructor(camera, dom, { bounds = 18 } = {}) {
    this.camera = camera;
    this.dom = dom;
    this.bounds = bounds;
    this.events = new EventBus();
    this.current = { ...DEFAULT_CAMERA };
    this.desired = { ...DEFAULT_CAMERA };
    this.pointers = new Map();
    this.mode = null;
    this.keys = new Set();
    this.enabled = true;
    this._moving = false;
    this._user = false;
    this._pinch = null;
    this._wheelTimer = null;

    this._onDown = this._onDown.bind(this);
    this._onMove = this._onMove.bind(this);
    this._onUp = this._onUp.bind(this);
    this._onWheel = this._onWheel.bind(this);
    this._onKeyDown = this._onKeyDown.bind(this);
    this._onKeyUp = this._onKeyUp.bind(this);
    this._onContext = (e) => e.preventDefault();
    this._onBlur = () => this.keys.clear();

    dom.addEventListener('pointerdown', this._onDown);
    dom.addEventListener('pointermove', this._onMove);
    dom.addEventListener('pointerup', this._onUp);
    dom.addEventListener('pointercancel', this._onUp);
    dom.addEventListener('wheel', this._onWheel, { passive: false });
    dom.addEventListener('contextmenu', this._onContext);
    window.addEventListener('keydown', this._onKeyDown);
    window.addEventListener('keyup', this._onKeyUp);
    window.addEventListener('blur', this._onBlur);
    this._apply();
  }

  on(type, fn) {
    return this.events.on(type, fn);
  }

  getState() {
    return { ...this.desired };
  }

  setState(pose, { immediate = false } = {}) {
    const next = { ...DEFAULT_CAMERA, ...(pose || {}) };
    this.desired = this._clamp(next);
    if (immediate) {
      this.current = { ...this.desired };
      this._moving = false;
      this._apply();
    } else {
      this._startMove(false);
    }
  }

  focus(px, pz, { distance } = {}) {
    this.desired.tx = px;
    this.desired.tz = pz;
    if (distance) this.desired.distance = distance;
    this.desired = this._clamp(this.desired);
    this._startMove(false);
  }

  rotateBy(rad) {
    this.desired.azimuth += rad;
    this._startMove(true);
  }

  zoomBy(factor) {
    this.desired.distance *= factor;
    this.desired = this._clamp(this.desired);
    this._startMove(true);
  }

  get isDragging() {
    return this.mode === 'pan' || this.mode === 'rotate' || this.mode === 'pinch';
  }

  update(dt) {
    this._applyKeys(dt);
    const a = 1 - Math.exp(-dt * 12);
    let diff = 0;
    for (const k of Object.keys(this.current)) {
      const d = this.desired[k] - this.current[k];
      this.current[k] += d * a;
      diff = Math.max(diff, Math.abs(d));
    }
    this._apply();
    if (this._moving && diff < 0.002 && !this.isDragging && this.keys.size === 0) {
      this.current = { ...this.desired };
      this._apply();
      this._moving = false;
      this.events.emit('settled', { camera: this.getState(), userInitiated: this._user });
      this._user = false;
    }
  }

  dispose() {
    const d = this.dom;
    d.removeEventListener('pointerdown', this._onDown);
    d.removeEventListener('pointermove', this._onMove);
    d.removeEventListener('pointerup', this._onUp);
    d.removeEventListener('pointercancel', this._onUp);
    d.removeEventListener('wheel', this._onWheel);
    d.removeEventListener('contextmenu', this._onContext);
    window.removeEventListener('keydown', this._onKeyDown);
    window.removeEventListener('keyup', this._onKeyUp);
    window.removeEventListener('blur', this._onBlur);
    this.events.clear();
  }

  // internals

  _startMove(user) {
    this._moving = true;
    if (user) this._user = true;
  }

  _clamp(p) {
    const b = this.bounds;
    return {
      tx: THREE.MathUtils.clamp(p.tx, -b, b),
      tz: THREE.MathUtils.clamp(p.tz, -b, b),
      azimuth: p.azimuth,
      polar: THREE.MathUtils.clamp(p.polar, LIMITS.minPolar, LIMITS.maxPolar),
      distance: THREE.MathUtils.clamp(p.distance, LIMITS.minDistance, LIMITS.maxDistance),
    };
  }

  _apply() {
    const { tx, tz, azimuth, polar, distance } = this.current;
    const s = Math.sin(polar);
    this.camera.position.set(tx + distance * s * Math.sin(azimuth), distance * Math.cos(polar), tz + distance * s * Math.cos(azimuth));
    this.camera.lookAt(tx, 0, tz);
  }

  _worldPerPixel() {
    const h = this.dom.clientHeight || 1;
    return (2 * this.current.distance * Math.tan(THREE.MathUtils.degToRad(this.camera.fov / 2))) / h;
  }

  _pan(dx, dy) {
    const k = this._worldPerPixel();
    const az = this.desired.azimuth;
    const kv = k / Math.max(Math.cos(this.desired.polar), 0.45);
    const right = { x: Math.cos(az), z: -Math.sin(az) };
    const fwd = { x: -Math.sin(az), z: -Math.cos(az) };
    this.desired.tx += -right.x * dx * k + fwd.x * dy * kv;
    this.desired.tz += -right.z * dx * k + fwd.z * dy * kv;
    this.desired = this._clamp(this.desired);
    this._startMove(true);
  }

  _onDown(e) {
    if (!this.enabled) return;
    this.dom.setPointerCapture?.(e.pointerId);
    this.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY, sx: e.clientX, sy: e.clientY });
    if (this.pointers.size === 2) {
      const [a, b] = [...this.pointers.values()];
      this.mode = 'pinch';
      this._pinch = { dist: Math.hypot(a.x - b.x, a.y - b.y), distance: this.desired.distance };
      return;
    }
    if (e.button === 2 || e.button === 1 || (e.button === 0 && e.shiftKey)) this.mode = 'rotate';
    else if (e.button === 0) this.mode = 'pending';
  }

  _onMove(e) {
    const p = this.pointers.get(e.pointerId);
    if (!p) return;
    const dx = e.clientX - p.x;
    const dy = e.clientY - p.y;
    p.x = e.clientX;
    p.y = e.clientY;
    if (this.mode === 'pinch' && this.pointers.size === 2) {
      const [a, b] = [...this.pointers.values()];
      const dist = Math.hypot(a.x - b.x, a.y - b.y) || 1;
      this.desired.distance = this._pinch.distance * (this._pinch.dist / dist);
      this.desired = this._clamp(this.desired);
      this._startMove(true);
      return;
    }
    if (this.mode === 'pending' && Math.hypot(e.clientX - p.sx, e.clientY - p.sy) > DRAG_THRESHOLD) {
      this.mode = 'pan';
      this.events.emit('dragstart');
    }
    if (this.mode === 'pan') this._pan(dx, dy);
    if (this.mode === 'rotate') {
      this.desired.azimuth -= dx * 0.008;
      this.desired.polar -= dy * 0.005;
      this.desired = this._clamp(this.desired);
      this._startMove(true);
    }
  }

  _onUp(e) {
    const p = this.pointers.get(e.pointerId);
    this.pointers.delete(e.pointerId);
    this.dom.releasePointerCapture?.(e.pointerId);
    if (!p) return;
    if (this.mode === 'pending' && e.type === 'pointerup') {
      this.events.emit('click', { clientX: e.clientX, clientY: e.clientY });
    }
    if (this.pointers.size === 0) this.mode = null;
    else if (this.mode === 'pinch') this.mode = null;
  }

  _onWheel(e) {
    if (!this.enabled) return;
    e.preventDefault();
    const delta = e.deltaMode === 1 ? e.deltaY * 16 : e.deltaY;
    this.desired.distance *= Math.exp(THREE.MathUtils.clamp(delta, -200, 200) * 0.0015);
    this.desired = this._clamp(this.desired);
    this._startMove(true);
  }

  _isTyping(e) {
    const t = e.target;
    return t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable);
  }

  _onKeyDown(e) {
    if (!this.enabled || this._isTyping(e) || e.metaKey || e.ctrlKey || e.altKey) return;
    const k = e.key.toLowerCase();
    if (['w', 'a', 's', 'd', 'q', 'e', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright', '+', '=', '-', '_'].includes(k)) {
      this.keys.add(k);
      if (k.startsWith('arrow')) e.preventDefault();
    }
  }

  _onKeyUp(e) {
    this.keys.delete(e.key.toLowerCase());
  }

  _applyKeys(dt) {
    if (!this.keys.size) return;
    const speed = 500 * dt; // pixels-equivalent per second
    const has = (...ks) => ks.some((k) => this.keys.has(k));
    let dx = 0;
    let dy = 0;
    if (has('w', 'arrowup')) dy += speed;
    if (has('s', 'arrowdown')) dy -= speed;
    if (has('a', 'arrowleft')) dx += speed;
    if (has('d', 'arrowright')) dx -= speed;
    if (dx || dy) this._pan(dx, dy);
    if (has('q')) this.rotateBy(-1.6 * dt);
    if (has('e')) this.rotateBy(1.6 * dt);
    if (has('+', '=')) this.zoomBy(Math.exp(-1.2 * dt));
    if (has('-', '_')) this.zoomBy(Math.exp(1.2 * dt));
  }
}
