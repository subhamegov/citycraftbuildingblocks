// The store is the only writer of game state.
//
// A command is a plain object:
//   {
//     type: 'world/clearTree',
//     touches: ['world', 'economy'],        // slices it may change
//     validate(state, payload, ctx) -> null | 'reason it cannot run',
//     apply(state, payload, ctx)           // mutates the working state
//   }
//
// validate() receives a read-only view. apply() receives the real state and a
// context with a deterministic RNG, config and helpers. Reactions run after
// every successful command inside the same transaction (used by missions).
// Listeners are notified after the transaction with the touched slices and
// any domain events, so the renderer and UI can update only what changed.

import { readonly } from './readonly.js';
import { createRng } from './rng.js';

export const REPLACE = '@@state/replace';

export class Store {
  constructor({ state, commands, reactions = [], context = {}, strict = true }) {
    if (!state) throw new Error('Store needs an initial state');
    this._state = state;
    this._commands = commands;
    this._reactions = reactions;
    this._context = context;
    this._strict = strict;
    this._listeners = new Set();
    this._dispatching = false;
    this._queue = [];
    this._sliceRevisions = {};
    this._history = [];
  }

  getState() {
    return this._strict ? readonly(this._state) : this._state;
  }

  get config() {
    return this._context.config;
  }

  sliceRevision(slice) {
    return this._sliceRevisions[slice] || 0;
  }

  has(type) {
    return this._commands.has(type);
  }

  /** Recent command log for debugging and future analytics. */
  history() {
    return this._history.slice();
  }

  subscribe(listener) {
    this._listeners.add(listener);
    return () => this._listeners.delete(listener);
  }

  /** Check whether a command would succeed, without running it. */
  canDispatch(type, payload = {}) {
    const def = this._commands.get(type);
    if (!def) return { ok: false, error: `Unknown command "${type}"` };
    const error = def.validate ? def.validate(readonly(this._state), payload, this._context) : null;
    return error ? { ok: false, error } : { ok: true };
  }

  dispatch(type, payload = {}) {
    if (this._dispatching) {
      // Commands are never nested. A listener that dispatches is queued and
      // runs after the current transaction finishes.
      this._queue.push({ type, payload });
      return { ok: true, queued: true };
    }
    const result = this._run(type, payload);
    while (this._queue.length) {
      const next = this._queue.shift();
      this._run(next.type, next.payload);
    }
    return result;
  }

  _run(type, payload) {
    const def = this._commands.get(type);
    if (!def) {
      const error = `Unknown command "${type}"`;
      this._notify({ type, payload, ok: false, error, events: [], touched: [] });
      return { ok: false, error };
    }
    const check = def.validate ? def.validate(readonly(this._state), payload, this._context) : null;
    if (check) {
      this._notify({ type, payload, ok: false, error: check, events: [], touched: [] });
      return { ok: false, error: check };
    }

    const state = this._state;
    const events = [];
    const touched = new Set(def.touches || []);
    let rng = null;
    const ctx = {
      ...this._context,
      command: type,
      day: state.simulation.day,
      get rng() {
        if (!rng) rng = createRng(state.meta.rngState);
        return rng;
      },
      emit(eventType, data = {}) {
        events.push({ type: eventType, ...data });
      },
      touch(...slices) {
        slices.forEach((s) => touched.add(s));
      },
      journal(text, kind = 'info') {
        const journal = state.simulation.journal;
        journal.push({ day: state.simulation.day, kind, text });
        const limit = this.config?.game?.journalLimit ?? 100;
        if (journal.length > limit) journal.splice(0, journal.length - limit);
        touched.add('simulation');
      },
    };

    this._dispatching = true;
    try {
      def.apply(state, payload, ctx);
      for (const reaction of this._reactions) reaction(state, { type, payload, events }, ctx);
      if (rng) state.meta.rngState = rng.state;
      // The revision counter is bookkeeping; it does not mark meta as touched.
      state.meta.revision += 1;
    } finally {
      this._dispatching = false;
    }

    for (const slice of touched) this._sliceRevisions[slice] = (this._sliceRevisions[slice] || 0) + 1;
    if (type !== 'sim/tick' && type !== 'ui/setCamera') {
      this._history.push({ type, revision: state.meta.revision, day: state.simulation.day });
      if (this._history.length > 200) this._history.shift();
    }
    const record = { type, payload, ok: true, events, touched: [...touched] };
    this._notify(record);
    return { ok: true, events };
  }

  /** Swap in a whole new state (load, reset, import). Everything re-renders. */
  replaceState(nextState, reason = 'load') {
    if (this._dispatching) throw new Error('Cannot replace state during a command');
    this._state = nextState;
    const touched = Object.keys(nextState);
    for (const slice of touched) this._sliceRevisions[slice] = (this._sliceRevisions[slice] || 0) + 1;
    this._notify({ type: REPLACE, payload: { reason }, ok: true, events: [], touched });
  }

  /** JSON text of the current state, used by persistence. */
  serialize() {
    return JSON.stringify(this._state);
  }

  _notify(record) {
    for (const listener of [...this._listeners]) {
      try {
        listener(record, this.getState());
      } catch (err) {
        console.error('[CityCraft] listener failed', err);
      }
    }
  }
}

export function createCommandRegistry(...groups) {
  const map = new Map();
  for (const group of groups) {
    for (const def of group) {
      if (map.has(def.type)) throw new Error(`Duplicate command "${def.type}"`);
      if (typeof def.apply !== 'function') throw new Error(`Command "${def.type}" has no apply()`);
      map.set(def.type, def);
    }
  }
  return map;
}
