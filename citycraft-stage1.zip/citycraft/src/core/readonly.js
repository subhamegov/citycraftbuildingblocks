// Read-only views of game state. Everything outside command handlers gets
// state through these proxies, so a stray write fails loudly instead of
// silently changing a record behind the store's back.

const cache = new WeakMap();

function refuse(key) {
  throw new Error(
    `CityCraft state is read-only outside commands. Dispatch a command instead (attempted to change "${String(key)}").`,
  );
}

const handler = {
  get(target, key, receiver) {
    const value = Reflect.get(target, key, receiver);
    return value !== null && typeof value === 'object' ? readonly(value) : value;
  },
  set(_t, key) {
    return refuse(key);
  },
  deleteProperty(_t, key) {
    return refuse(key);
  },
  defineProperty(_t, key) {
    return refuse(key);
  },
};

export function readonly(value) {
  if (value === null || typeof value !== 'object') return value;
  let proxy = cache.get(value);
  if (!proxy) {
    proxy = new Proxy(value, handler);
    cache.set(value, proxy);
  }
  return proxy;
}

export function deepFreeze(obj) {
  if (obj && typeof obj === 'object' && !Object.isFrozen(obj)) {
    Object.freeze(obj);
    for (const key of Object.keys(obj)) deepFreeze(obj[key]);
  }
  return obj;
}
