// Deterministic random numbers. The generator state is a single uint32 that
// lives in game state (meta.rngState), so replaying the same commands from the
// same state always gives the same result.

export function stepRandom(state) {
  const next = (state + 0x6d2b79f5) >>> 0;
  let r = Math.imul(next ^ (next >>> 15), next | 1);
  r ^= r + Math.imul(r ^ (r >>> 7), r | 61);
  return { value: ((r ^ (r >>> 14)) >>> 0) / 4294967296, state: next };
}

export function createRng(seed) {
  let s = seed >>> 0;
  return {
    next() {
      const out = stepRandom(s);
      s = out.state;
      return out.value;
    },
    int(min, max) {
      return min + Math.floor(this.next() * (max - min + 1));
    },
    pick(list) {
      return list[Math.floor(this.next() * list.length)];
    },
    get state() {
      return s;
    },
  };
}

// Stateless hash for per-tile variation (stable regardless of call order).
export function hash2(x, y, seed = 0) {
  let h = (seed ^ Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263)) >>> 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177) >>> 0;
  h = (h ^ (h >>> 16)) >>> 0;
  return h / 4294967296;
}

export function hashString(text) {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h >>> 0;
}

// Smooth value noise in [0,1), used for terrain and forests.
export function valueNoise(x, y, seed, scale = 8) {
  const fx = x / scale;
  const fy = y / scale;
  const x0 = Math.floor(fx);
  const y0 = Math.floor(fy);
  const tx = fx - x0;
  const ty = fy - y0;
  const sx = tx * tx * (3 - 2 * tx);
  const sy = ty * ty * (3 - 2 * ty);
  const a = hash2(x0, y0, seed);
  const b = hash2(x0 + 1, y0, seed);
  const c = hash2(x0, y0 + 1, seed);
  const d = hash2(x0 + 1, y0 + 1, seed);
  const top = a + (b - a) * sx;
  const bottom = c + (d - c) * sx;
  return top + (bottom - top) * sy;
}

export function randomSeed() {
  // Only used outside commands, when a brand new city is created.
  return (Math.floor(Math.random() * 0xffffffff) >>> 0) || 1;
}
