import { STATE_VERSION } from './schema.js';
import { generateWorld } from '../physical/worldGen.js';
import { createRegistries } from '../registries/index.js';
import { createPlatformState } from '../platform/index.js';
import { createMunicipalState } from '../municipal/index.js';
import { createEconomyState } from '../simulation/economy.js';
import { createMissionState } from '../analytics/missions.js';

export function createInitialState(config, { seed, cityName } = {}) {
  const s = (seed >>> 0) || 1;
  const world = generateWorld(config, s);
  return {
    meta: {
      version: STATE_VERSION,
      seed: s,
      rngState: s,
      revision: 0,
      cityName: (cityName || config.game.defaultCityName).trim(),
      manualSaves: 0,
      lastSavedDay: null,
    },
    world,
    registries: createRegistries(config, world),
    platform: createPlatformState(config),
    municipalServices: createMunicipalState(config),
    economy: createEconomyState(config),
    simulation: {
      day: 0,
      speed: config.game.simulation.startSpeed,
      population: 0,
      happiness: config.game.startingHappiness,
      journal: [{ day: 0, kind: 'info', text: 'You have taken office as mayor.' }],
    },
    ui: {
      activeView: 'city',
      activeTool: 'select',
      selection: null,
      overlays: { wards: true, plots: false },
      camera: null,
      settings: {
        autosave: config.game.autosave.enabled,
        autosaveEveryDays: config.game.autosave.everyDays,
        showHints: true,
      },
    },
    missions: createMissionState(config),
  };
}
