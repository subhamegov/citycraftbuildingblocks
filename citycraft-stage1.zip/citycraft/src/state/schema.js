// The shape of a CityCraft save. Bump STATE_VERSION whenever the shape
// changes and add a matching step in migrations.js.

export const STATE_VERSION = 1;

export const STATE_SLICES = [
  'meta', // version, seed, RNG state, city name, revision counter
  'world', // physical grid: terrain, trees, structures
  'registries', // shared records: boundaries, properties, addresses, people...
  'platform', // reusable platform services and their status
  'municipalServices', // municipal applications and their cases
  'economy', // treasury, ledger, monthly accounts
  'simulation', // date, speed, population, happiness, journal
  'ui', // saved interface state: view, tool, selection, camera, settings
  'missions', // goals, facts and completions
];

export function validateState(state) {
  const errors = [];
  if (!state || typeof state !== 'object') return { ok: false, errors: ['State is not an object'] };
  for (const slice of STATE_SLICES) if (!state[slice] || typeof state[slice] !== 'object') errors.push(`Missing slice "${slice}"`);
  if (errors.length) return { ok: false, errors };
  const { world } = state;
  if (!Array.isArray(world.tiles) || world.tiles.length !== world.width * world.height) {
    errors.push('world.tiles does not match world size');
  } else {
    // Each tile must sit at its own index. Catches duplicated or shuffled tiles.
    for (let i = 0; i < world.tiles.length; i++) {
      const t = world.tiles[i];
      if (t.y * world.width + t.x !== i) {
        errors.push(`Tile at index ${i} has wrong coordinates`);
        break;
      }
    }
  }
  if (!Number.isFinite(state.economy.treasury)) errors.push('economy.treasury is not a number');
  if (!Number.isInteger(state.simulation.day) || state.simulation.day < 0) errors.push('simulation.day is invalid');
  if (state.meta.version !== STATE_VERSION) errors.push(`State version ${state.meta.version} is not ${STATE_VERSION}`);
  return { ok: errors.length === 0, errors };
}
