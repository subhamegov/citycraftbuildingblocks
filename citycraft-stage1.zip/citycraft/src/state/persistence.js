// Saving and loading with localStorage.
//
// A save is an envelope around the state:
//   { format, version, slot, savedAt, cityName, day, state }
// Two slots exist: "manual" (Save button) and "auto" (autosave). On start the
// newest valid save is loaded. Loading replaces the whole state in one step,
// so nothing is merged or duplicated.

import { STATE_VERSION, validateState } from './schema.js';
import { migrateState } from './migrations.js';

export const SAVE_FORMAT = 'citycraft-save';
export const SLOTS = ['manual', 'auto'];
const KEY_PREFIX = 'citycraft:v1:';

function keyFor(slot) {
  return `${KEY_PREFIX}${slot}`;
}

function memoryStorage() {
  const data = new Map();
  return {
    getItem: (k) => (data.has(k) ? data.get(k) : null),
    setItem: (k, v) => data.set(k, String(v)),
    removeItem: (k) => data.delete(k),
  };
}

export function safeLocalStorage() {
  try {
    const ls = globalThis.localStorage;
    const probe = '__citycraft_probe__';
    ls.setItem(probe, '1');
    ls.removeItem(probe);
    return { storage: ls, persistent: true };
  } catch {
    return { storage: memoryStorage(), persistent: false };
  }
}

export function parseSave(text, { migrationRegistry } = {}) {
  let envelope;
  try {
    envelope = JSON.parse(text);
  } catch {
    throw new Error('This file is not a CityCraft save (not valid JSON).');
  }
  if (envelope?.format !== SAVE_FORMAT || !envelope.state) throw new Error('This file is not a CityCraft save.');
  const { state, applied } = migrateState(envelope.state, migrationRegistry ? { registry: migrationRegistry } : undefined);
  const check = validateState(state);
  if (!check.ok) throw new Error(`Save is damaged: ${check.errors.join('; ')}`);
  return { state, applied, envelope };
}

export class Persistence {
  constructor({ storage, clock = () => new Date().toISOString() } = {}) {
    const resolved = storage ? { storage, persistent: true } : safeLocalStorage();
    this.storage = resolved.storage;
    this.persistent = resolved.persistent;
    this.clock = clock;
    this.store = null;
    this._lastAutosaveDay = null;
    this._unsub = null;
  }

  attach(store) {
    this.store = store;
    this._unsub?.();
    this._unsub = store.subscribe((record, state) => this._maybeAutosave(record, state));
  }

  buildEnvelope(slot) {
    const state = JSON.parse(this.store.serialize());
    return {
      format: SAVE_FORMAT,
      version: STATE_VERSION,
      slot,
      savedAt: this.clock(),
      cityName: state.meta.cityName,
      day: state.simulation.day,
      state,
    };
  }

  save(slot = 'manual') {
    if (!SLOTS.includes(slot)) throw new Error(`Unknown save slot ${slot}`);
    this.store.dispatch('meta/recordSave', { slot });
    const envelope = this.buildEnvelope(slot);
    const text = JSON.stringify(envelope);
    try {
      this.storage.setItem(keyFor(slot), text);
    } catch (err) {
      return { ok: false, error: `Could not save: ${err.message || 'storage is full or blocked'}` };
    }
    if (slot === 'auto') this._lastAutosaveDay = envelope.day;
    return { ok: true, bytes: text.length, envelope };
  }

  info(slot) {
    const text = this.storage.getItem(keyFor(slot));
    if (!text) return null;
    try {
      const env = JSON.parse(text);
      return { slot, savedAt: env.savedAt, cityName: env.cityName, day: env.day, version: env.version, bytes: text.length };
    } catch {
      return { slot, damaged: true };
    }
  }

  /** Newest readable save, or null. */
  latestSlot() {
    const infos = SLOTS.map((s) => this.info(s)).filter((i) => i && !i.damaged);
    infos.sort((a, b) => String(b.savedAt).localeCompare(String(a.savedAt)));
    return infos[0]?.slot ?? null;
  }

  read(slot) {
    const text = this.storage.getItem(keyFor(slot));
    if (!text) throw new Error('There is no saved city in this slot.');
    return parseSave(text);
  }

  /** Load a slot into the attached store. */
  load(slot = 'manual') {
    const { state, applied } = this.read(slot);
    this.store.replaceState(state, 'load');
    this._lastAutosaveDay = state.simulation.day;
    return { ok: true, applied, day: state.simulation.day };
  }

  exportText() {
    return JSON.stringify(this.buildEnvelope('export'), null, 0);
  }

  importText(text) {
    const { state, applied } = parseSave(text);
    this.store.replaceState(state, 'import');
    return { ok: true, applied };
  }

  clearAll() {
    for (const slot of SLOTS) this.storage.removeItem(keyFor(slot));
  }

  _maybeAutosave(record, state) {
    if (record.type !== 'sim/tick' || !record.ok) return;
    const { autosave, autosaveEveryDays } = state.ui.settings;
    const day = state.simulation.day;
    if (!autosave || day % autosaveEveryDays !== 0 || this._lastAutosaveDay === day) return;
    // Defer so the save happens after the current dispatch finishes.
    queueMicrotask(() => {
      const res = this.save('auto');
      this.onAutosave?.(res);
    });
  }
}
