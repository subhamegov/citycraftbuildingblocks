// Save migrations. Each entry upgrades a state from version N to N + 1.
// When STATE_VERSION goes to 2, add:
//
//   1: (state) => { state.world.roads = []; state.meta.version = 2; return state; }
//
// Migrations must be pure data transforms with no randomness or clock reads.

import { STATE_VERSION } from './schema.js';

export const migrations = {};

export function migrateState(state, { registry = migrations, target = STATE_VERSION } = {}) {
  let version = state?.meta?.version;
  if (!Number.isInteger(version)) throw new Error('Save has no version number');
  if (version > target) {
    throw new Error(`This save was made by a newer version of CityCraft (save v${version}, game v${target}).`);
  }
  const applied = [];
  while (version < target) {
    const step = registry[version];
    if (!step) throw new Error(`No migration from save version ${version}`);
    state = step(state);
    if (state.meta.version !== version + 1) throw new Error(`Migration from v${version} did not set version ${version + 1}`);
    applied.push(`${version}->${version + 1}`);
    version += 1;
  }
  return { state, applied };
}
