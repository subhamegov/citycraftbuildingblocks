// Derived numbers for the Insights view and inspectors. Pure functions over
// state. Nothing here is stored, so it can never drift out of sync.

import { isOpenPlot } from '../physical/tiles.js';
import { wardName } from '../registries/index.js';
import { countRecords } from '../registries/registry.js';

export function landSummary(config, tiles) {
  const out = { tiles: 0, land: 0, water: 0, shore: 0, wooded: 0, open: 0, developed: 0 };
  for (const t of tiles) {
    out.tiles += 1;
    if (t.terrain === 'water') out.water += 1;
    else if (t.terrain === 'sand') out.shore += 1;
    else out.land += 1;
    if (t.tree) out.wooded += 1;
    if (t.structure) out.developed += 1;
    if (isOpenPlot(config, t)) out.open += 1;
  }
  return out;
}

export function wardSummaries(state, config) {
  return config.wards.wards.map((w) => {
    const tiles = state.world.tiles.filter((t) => t.ward === w.code);
    return { code: w.code, color: w.color, name: wardName(state.registries, w.code), population: 0, ...landSummary(config, tiles) };
  });
}

export function cityMetrics(state, config) {
  const land = landSummary(config, state.world.tiles);
  const registryCounts = {};
  for (const def of config.registries.registries) registryCounts[def.id] = countRecords(state.registries[def.id]);
  return {
    treasury: state.economy.treasury,
    population: state.simulation.population,
    happiness: state.simulation.happiness,
    day: state.simulation.day,
    land,
    registryCounts,
    missionsDone: Object.keys(state.missions.completed).length,
    missionsTotal: config.missions.missions.length,
  };
}
