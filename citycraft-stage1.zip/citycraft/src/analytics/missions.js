// Missions are goals defined in config/data/missions.json. Progress comes
// from "facts" the game records as the player acts, plus values read from
// state. Evaluation runs as a store reaction after every command.

import { getTile } from '../physical/tiles.js';

export function createMissionState(config) {
  return {
    active: config.missions.missions.map((m) => m.id),
    completed: {},
    facts: { cameraMoved: 0, tilesInspected: 0, wardsInspected: [], saves: 0 },
  };
}

// How to measure each goal type. Add new types here in later stages.
export const goalMeasures = {
  fact: (state, goal) => {
    const v = state.missions.facts[goal.fact];
    return Array.isArray(v) ? v.length : Number(v) || 0;
  },
  daysElapsed: (state) => state.simulation.day,
  treasuryAtLeast: (state) => state.economy.treasury,
  population: (state) => state.simulation.population,
};

export function missionProgress(state, mission) {
  const measure = goalMeasures[mission.goal.type];
  const value = measure ? measure(state, mission.goal) : 0;
  const target = mission.goal.target;
  return { value: Math.min(value, target), target, done: value >= target };
}

// Which commands produce which facts.
function recordFacts(state, { type, payload }) {
  const facts = state.missions.facts;
  let changed = false;
  if (type === 'ui/setCamera' && payload.userInitiated && !facts.cameraMoved) {
    facts.cameraMoved = 1;
    changed = true;
  }
  if (type === 'ui/select' && payload.selection) {
    const sel = payload.selection;
    if (sel.kind === 'tile' && getTile(state.world, sel.x, sel.y)) {
      facts.tilesInspected += 1;
      changed = true;
    }
    if (sel.kind === 'ward' && !facts.wardsInspected.includes(sel.code)) {
      facts.wardsInspected.push(sel.code);
      facts.wardsInspected.sort();
      changed = true;
    }
  }
  if (type === 'meta/recordSave' && (payload.slot ?? 'manual') === 'manual') {
    facts.saves += 1;
    changed = true;
  }
  return changed;
}

export function missionsReaction(state, command, ctx) {
  const factsChanged = recordFacts(state, command);
  if (factsChanged) ctx.touch('missions');
  if (!state.missions.active.length) return;
  const defs = ctx.config.missions.missions;
  for (const id of [...state.missions.active]) {
    const mission = defs.find((m) => m.id === id);
    if (!mission) continue;
    if (missionProgress(state, mission).done) {
      state.missions.active = state.missions.active.filter((m) => m !== id);
      state.missions.completed[id] = state.simulation.day;
      ctx.touch('missions');
      ctx.emit('mission.completed', { id, title: mission.title });
      ctx.journal(`Mission complete: ${mission.title}.`, 'success');
    }
  }
}
