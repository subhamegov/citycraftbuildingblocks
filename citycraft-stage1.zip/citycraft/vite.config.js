import { defineConfig } from 'vite';

// Relative base so the built site can be hosted from any static folder or sub-path.
export default defineConfig({
  base: './',
  build: {
    outDir: 'dist',
    target: 'es2020',
    chunkSizeWarningLimit: 900,
  },
  server: { open: true },
});
