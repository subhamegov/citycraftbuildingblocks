# Architecture

The game is built so that the next nine stages add modules and data, not rewrites.

## The one rule

**All game state changes go through `store.dispatch(type, payload)`.**

Everything else reads state through a read-only view. A stray write outside a command throws an error that says which field was touched.

```
player input ──> renderer / UI ──emit intent──> actions ──dispatch──> Store
                                                                       │
                     renderer <── world view <── bridge <── notify ────┤
                     panels   <───────────────── notify ───────────────┘
```

## Folders

| Folder | Responsibility |
|---|---|
| `src/core/` | Store and command pipeline, read-only proxies, seeded random numbers, event bus |
| `src/state/` | State schema and version, initial state, save and load, migrations |
| `src/config/` | JSON game data (`data/*.json`) and the loader that validates and freezes it |
| `src/physical/` | Physical city: tile queries, world generation, landscaping commands |
| `src/registries/` | Shared entity registries (generic record store, boundaries, rename command) |
| `src/platform/` | Reusable platform services: state shape and service contract |
| `src/municipal/` | Municipal applications: state shape and application contract |
| `src/simulation/` | Calendar, clock, daily systems, economy and ledger |
| `src/analytics/` | Derived metrics and missions |
| `src/render/` | Three.js scene, layers, camera controller, picking, mini-map |
| `src/ui/` | Design system components, panels, views, overlays, shortcuts |
| `src/app/` | Composition: command registry, renderer bridge, world view, player actions |

## State

`STATE_VERSION = 1`. Top-level slices:

- `meta`: version, seed, RNG state, city name, revision counter, save counts
- `world`: grid size, tiles (`{x, y, ward, terrain, shade, tree, structure}`), `structures` map for later stages
- `registries`: `boundaries`, `properties`, `addresses`, `people`, `businesses`, `assets`. Same shape for all: `{kind, idPrefix, nextSeq, order, records}`
- `platform`: one entry per shared service with a status
- `municipalServices`: one entry per application, plus `cases` that will reference registry ids
- `economy`: treasury, ledger, monthly accounts
- `simulation`: day, speed, population, happiness, journal
- `ui`: saved interface state (view, tool, selection, overlays, camera, settings). Hover is transient and not stored.
- `missions`: active, completed, facts

## Commands

A command is data plus two functions:

```js
{
  type: 'world/clearTree',
  touches: ['world', 'economy'],          // slices it may change
  validate(state, payload, ctx) { ... },  // read-only; return an error string or null
  apply(state, payload, ctx) { ... },     // the only place state is mutated
}
```

`ctx` gives `config`, a seeded `rng` (state saved in `meta.rngState`), `emit(event)`, `touch(slice)` and `journal(text)`. Commands must not read the wall clock or `Math.random`, so the same state plus the same commands always gives the same result. The tests check this.

Register new groups in `src/app/commandRegistry.js`.

## Keeping the layers apart

- **Renderer** (`src/render/`) never imports registries, services or commands. It draws a plain world view built by `src/app/worldView.js` and emits `hover`, `tileClick` and `cameraSettled`.
- **Bridge** (`src/app/rendererBridge.js`) is the only file that knows both sides.
- **Registries** hold one record per real thing. Tiles and later services refer to records by id (a tile stores `ward: 'W2'`, the boundary record holds the name). Renaming a ward changes one record and every screen updates.
- **Platform services and municipal applications** will read and write registry records through commands, never keep copies.

## Saves

A save is `{format, version, slot, savedAt, cityName, day, state}` in localStorage under `citycraft:v1:<slot>`. Slots are `manual` and `auto`. On start, the newest valid save loads. Loading replaces the whole state in one step and the renderer rebuilds every layer from it, so objects are never duplicated (the Insights engine check shows the counts).

To change the state shape: bump `STATE_VERSION` in `src/state/schema.js` and add a step in `src/state/migrations.js` that upgrades version N to N + 1.

## Adding things in later stages

- **A new building type**: add it to config, add a `world/build...` command that writes `world.structures` and registers a property record, and add a render layer that draws structures from the world view.
- **A daily process** (population, utilities, billing): `registerSystem({ id, run(state, ctx) })` in `src/simulation/systems.js`.
- **A platform service**: implement the `PlatformService` contract in `src/platform/` and add an activation command.
- **A municipal application**: implement the `MunicipalApplication` contract in `src/municipal/`, listing the platform services it uses.
- **A new mission goal**: add a measure to `goalMeasures` in `src/analytics/missions.js` and a mission entry in `config/data/missions.json`.
- **A new view**: create it in `src/ui/views/` with `render(state)` and `slices`, and add it to `src/ui/app.js` and the bottom nav.
