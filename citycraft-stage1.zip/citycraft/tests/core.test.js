import { test } from 'node:test';
import assert from 'node:assert/strict';
import { loadTestConfig, memoryStorage } from './helpers.js';
import { createStore, newGameState } from '../src/app/createGame.js';
import { Persistence, parseSave } from '../src/state/persistence.js';
import { validateState, STATE_VERSION, STATE_SLICES } from '../src/state/schema.js';
import { migrateState } from '../src/state/migrations.js';
import { getTile } from '../src/physical/tiles.js';
import { formatGameDate } from '../src/simulation/calendar.js';

const config = await loadTestConfig();

function findTile(state, pred) {
  return state.world.tiles.find(pred);
}

test('initial state matches the stage 1 brief', () => {
  const s = newGameState(config, { seed: 42 });
  for (const slice of STATE_SLICES) assert.ok(s[slice], `missing ${slice}`);
  assert.equal(s.meta.version, STATE_VERSION);
  assert.equal(s.economy.treasury, 100000);
  assert.equal(s.simulation.population, 0);
  assert.equal(s.world.width, 32);
  assert.equal(s.world.tiles.length, 32 * 32);
  assert.equal(s.registries.boundaries.order.length, 4);
  assert.ok(validateState(s).ok);
  const wards = new Set(s.world.tiles.map((t) => t.ward));
  assert.equal(wards.size, 4);
  assert.ok(s.world.tiles.some((t) => t.terrain === 'water'), 'has a lake');
  assert.ok(s.world.tiles.some((t) => t.tree), 'has trees');
});

test('world generation is deterministic per seed', () => {
  const a = JSON.stringify(newGameState(config, { seed: 7 }).world);
  const b = JSON.stringify(newGameState(config, { seed: 7 }).world);
  const c = JSON.stringify(newGameState(config, { seed: 8 }).world);
  assert.equal(a, b);
  assert.notEqual(a, c);
});

function playScript(store) {
  const s = store.getState();
  const wooded = findTile(s, (t) => t.tree);
  const open = findTile(s, (t) => !t.tree && (t.terrain === 'grass' || t.terrain === 'meadow'));
  store.dispatch('sim/setSpeed', { speed: 2 });
  store.dispatch('world/clearTree', { x: wooded.x, y: wooded.y });
  store.dispatch('world/plantTree', { x: open.x, y: open.y });
  for (let i = 0; i < 40; i++) store.dispatch('sim/tick');
  store.dispatch('ui/select', { selection: { kind: 'ward', code: 'W2' } });
  store.dispatch('registry/renameWard', { code: 'W3', name: 'Market Quarter' });
  return { wooded, open };
}

test('same commands from same state give identical results', () => {
  const s1 = createStore(config, newGameState(config, { seed: 99 }));
  const s2 = createStore(config, newGameState(config, { seed: 99 }));
  playScript(s1);
  playScript(s2);
  assert.equal(s1.serialize(), s2.serialize());
});

test('commands change state and the ledger explains treasury changes', () => {
  const store = createStore(config, newGameState(config, { seed: 5 }));
  const { wooded, open } = playScript(store);
  const s = store.getState();
  assert.equal(getTile(s.world, wooded.x, wooded.y).tree, null);
  assert.ok(getTile(s.world, open.x, open.y).tree);
  assert.equal(s.economy.treasury, 100000 - 50 - 20);
  assert.equal(s.economy.ledger.length, 2);
  assert.equal(s.simulation.day, 40);
  assert.equal(s.economy.months.length, 1, 'January closed on 1 Feb');
  assert.equal(formatGameDate(0), '1 Jan, Year 1');
  assert.equal(formatGameDate(40), '10 Feb, Year 1');
  assert.ok(s.missions.completed['first-week'] !== undefined);
});

test('state is read-only outside commands', () => {
  const store = createStore(config, newGameState(config, { seed: 1 }));
  assert.throws(() => {
    store.getState().economy.treasury = 5;
  }, /read-only/);
  assert.throws(() => {
    store.getState().world.tiles[0].tree = 'pine';
  }, /read-only/);
});

test('invalid commands are rejected without changing state', () => {
  const store = createStore(config, newGameState(config, { seed: 3 }));
  const before = store.serialize();
  const water = findTile(store.getState(), (t) => t.terrain === 'water');
  assert.equal(store.dispatch('world/plantTree', { x: water.x, y: water.y }).ok, false);
  assert.equal(store.dispatch('world/clearTree', { x: 99, y: 0 }).ok, false);
  assert.equal(store.dispatch('sim/setSpeed', { speed: 7 }).ok, false);
  assert.equal(store.dispatch('nope/unknown').ok, false);
  assert.equal(store.serialize(), before);
});

test('save then load restores the same state without duplication', () => {
  const storage = memoryStorage();
  const store = createStore(config, newGameState(config, { seed: 11 }));
  const persistence = new Persistence({ storage });
  persistence.attach(store);
  playScript(store);
  const res = persistence.save('manual');
  assert.ok(res.ok);
  const savedText = store.serialize();

  // Keep playing, then load: everything after the save must disappear.
  store.dispatch('sim/tick');
  const tree = findTile(store.getState(), (t) => t.tree);
  store.dispatch('world/clearTree', { x: tree.x, y: tree.y });
  persistence.load('manual');
  assert.equal(store.serialize(), savedText);

  // Load twice: still identical, still 1024 tiles, 4 wards.
  persistence.load('manual');
  const s = store.getState();
  assert.equal(store.serialize(), savedText);
  assert.equal(s.world.tiles.length, 1024);
  assert.equal(s.registries.boundaries.order.length, 4);
  assert.equal(s.meta.manualSaves, 1);
  assert.equal(s.missions.facts.saves, 1);

  // A fresh store (simulating a page reload) restores the same city.
  const persistence2 = new Persistence({ storage });
  const reloaded = createStore(config, persistence2.read(persistence2.latestSlot()).state);
  assert.equal(reloaded.serialize(), savedText);
});

test('autosave writes the auto slot on schedule', async () => {
  const storage = memoryStorage();
  const store = createStore(config, newGameState(config, { seed: 12 }));
  const persistence = new Persistence({ storage, clock: () => '2030-01-01T00:00:00.000Z' });
  persistence.attach(store);
  for (let i = 0; i < 7; i++) store.dispatch('sim/tick');
  await new Promise((r) => setTimeout(r, 0));
  const info = persistence.info('auto');
  assert.ok(info, 'auto slot written');
  assert.equal(info.day, 7);
});

test('export and import round trip', () => {
  const storage = memoryStorage();
  const store = createStore(config, newGameState(config, { seed: 13 }));
  const persistence = new Persistence({ storage });
  persistence.attach(store);
  playScript(store);
  const text = persistence.exportText();
  const other = createStore(config, newGameState(config, { seed: 14 }));
  const p2 = new Persistence({ storage: memoryStorage() });
  p2.attach(other);
  p2.importText(text);
  assert.equal(other.serialize(), store.serialize());
  assert.throws(() => p2.importText('{"hello":1}'), /not a CityCraft save/);
});

test('migration interface upgrades old saves and refuses newer ones', () => {
  const s = newGameState(config, { seed: 2 });
  const old = structuredClone(s);
  old.meta.version = 0;
  delete old.ui.settings.showHints;
  const registry = {
    0: (st) => {
      st.ui.settings.showHints = true;
      st.meta.version = 1;
      return st;
    },
  };
  const { state, applied } = migrateState(old, { registry });
  assert.deepEqual(applied, ['0->1']);
  assert.equal(JSON.stringify(state), JSON.stringify(s));
  const newer = structuredClone(s);
  newer.meta.version = 99;
  assert.throws(() => migrateState(newer), /newer version/);
  assert.throws(() => parseSave(JSON.stringify({ format: 'citycraft-save', state: newer })), /newer version/);
});

test('validateState catches duplicated tiles', () => {
  const s = newGameState(config, { seed: 4 });
  s.world.tiles.push({ ...s.world.tiles[0] });
  assert.equal(validateState(s).ok, false);
});

test('missions progress from player actions', () => {
  const store = createStore(config, newGameState(config, { seed: 21 }));
  store.dispatch('ui/setCamera', { camera: { tx: 1, tz: 1, azimuth: 1, polar: 1, distance: 30 }, userInitiated: true });
  store.dispatch('ui/select', { selection: { kind: 'tile', x: 3, y: 3 } });
  for (const code of ['W1', 'W2', 'W3', 'W4']) store.dispatch('ui/select', { selection: { kind: 'ward', code } });
  const m = store.getState().missions;
  assert.ok('look-around' in m.completed);
  assert.ok('inspect-plot' in m.completed);
  assert.ok('know-wards' in m.completed);
  assert.equal(m.active.length, 2);
});
